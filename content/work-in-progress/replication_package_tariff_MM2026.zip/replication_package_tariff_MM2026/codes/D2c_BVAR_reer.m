
% BVAR with REER


clearvars -except anchorSet
clc
if ~exist('anchorSet','var'); anchorSet = 'baseline'; end

%% ── Paths ──
codeDir = fileparts(mfilename('fullpath'));
rootDir = fileparts(codeDir);
addpath(genpath(fullfile(codeDir, 'functions')));

%% ── Data ─────────────────────────────────────────────────────────────────
datafile    = fullfile(rootDir, 'dataset', 'TariffData_CA_reer.mat');
panelselect = 1:10;

endYear      = 2025;
endQuarter   = 2;

%% ── Model specification ──────────────────────────────────────────────────

constant = 1;
exog     = [];
p        = 4;
h        = 0;

%% ── Reduced-form prior ───────────────────────────────────────────────────

prior_settings.prior_family = 'conjugate';
prior_settings.prior        = 'flat';

%% ── Structural identification ────────────────────────────────────────────

StructuralIdentification = 'Signs/Zeros';
agnostic                 = 'irfs';

SR  = {};
ZR  = {};
NSR = {};
EBR = {};

%% ── Dominance identification settings ───────────────────────────────────

h_dominance  = 1;
tau_idx      = 9;
neer_idx     = 8;

if strcmp(anchorSet, 'extended')
    anchor_dates = [datenum(2018, 10, 1); datenum(2019,7,1); datenum(2019,10,1); datenum(2025, 4, 1)];
else
    anchor_dates = [datenum(2018, 10, 1); datenum(2025, 4, 1)];
end
anchor_signs = ones(numel(anchor_dates), 1);


%% ── Imports sign restriction ─────────────────────────────────────────────

imp_idx        = 3;
imp_sign_restr = -1;
h_imp          = 2;

n_bvar           = numel(panelselect);
b_sign           = zeros(n_bvar,1);
b_sign(tau_idx)  = +1;
b_tol            = 0;

%% ── Sampler settings ─────────────────────────────────────────────────────

numDesiredDraws  = 1000;
BetaSigmaTries   = 100;
Qs_per_BetaSigma = 100;
nRepsWeights     = 1000;

cumulateWhich = [];
hmax_plot     = 15;

%% ── Run 1: 1990Q1–2025Q2 ─────────────────────────────────────────────────

startYear    = 1990;
startQuarter = 1;
tau_idx      = 9;

rng('default')
Run_SVAR_tariff_SignImports_signrestriction

reer_col = find(strcmpi(varNames, 'log_reer'));
tau_col  = find(strcmpi(varNames, 'weighted_tau'));

impact_draws = squeeze(Draws_IRFs(tau_col, 1, 1, :));
impact_med   = median(impact_draws);
if ~isfinite(impact_med) || abs(impact_med) < 1e-12
    scale_1990 = 1;
else
    scale_1990 = 1 / impact_med;
end

reer_irfs_1990 = squeeze(Draws_IRFs(reer_col, 1, 1:hmax_plot+1, :)) * scale_1990;
numDraws_1990  = numSavedDraws;
fprintf('\nRun 1 (1990Q1) done. %d admissible draws.\n', numDraws_1990);

%% ── Run 2: 2002Q1–2025Q2 ─────────────────────────────────────────────────

startYear    = 2002;
startQuarter = 1;
tau_idx      = 9;
exog         = [];

rng('default')
Run_SVAR_tariff_SignImports_signrestriction

reer_col = find(strcmpi(varNames, 'log_reer'));
tau_col  = find(strcmpi(varNames, 'weighted_tau'));

impact_draws = squeeze(Draws_IRFs(tau_col, 1, 1, :));
impact_med   = median(impact_draws);
if ~isfinite(impact_med) || abs(impact_med) < 1e-12
    scale_2002 = 1;
else
    scale_2002 = 1 / impact_med;
end

reer_irfs_2002 = squeeze(Draws_IRFs(reer_col, 1, 1:hmax_plot+1, :)) * scale_2002;
numDraws_2002  = numSavedDraws;
fprintf('\nRun 2 (2002Q1) done. %d admissible draws.\n', numDraws_2002);

%% ── Save REER IRFs ────────────────────────────────────────────────────────

out_dir = fullfile(rootDir, 'output');

if ~exist(out_dir, 'dir')
    mkdir(out_dir);
end

save(fullfile(out_dir, sprintf('REER_IRFs_RobustnessStartDate_%s.mat', anchorSet)), ...
    'reer_irfs_1990', 'reer_irfs_2002', 'hmax_plot', ...
    'numDraws_1990', 'numDraws_2002', '-v7.3');

fprintf('REER IRFs saved to %s\n', fullfile(out_dir, sprintf('REER_IRFs_RobustnessStartDate_%s.mat', anchorSet)));

%% ── Plot 1×2 comparison ──────────────────────────────────────────────────

horizons = (0:hmax_plot)';
xfill    = [horizons; flipud(horizons)];

set(groot, 'defaultAxesTickLabelInterpreter', 'latex');
set(groot, 'defaultTextInterpreter',          'latex');
set(groot, 'defaultLegendInterpreter',        'latex');
set(groot, 'defaultAxesFontName',             'Times New Roman');
set(groot, 'defaultTextFontName',             'Times New Roman');

fig = figure('Color', 'w', 'Units', 'pixels', 'Position', [100 100 1400 500]);

panel_data   = {reer_irfs_1990; reer_irfs_2002};
panel_labels = {'\textrm{(a) 1990--2025}'; '\textrm{(b) 2002--2025}'};

ax_handles = gobjects(1, 2);

for k = 1:2
    ax = subplot(1, 2, k);
    ax_handles(k) = ax;
    hold(ax, 'on');

    irfs    = panel_data{k};
    med_irf = median(irfs, 2);
    lb90    = quantile(irfs, 0.05, 2);
    ub90    = quantile(irfs, 0.95, 2);
    lb68    = quantile(irfs, 0.16, 2);
    ub68    = quantile(irfs, 0.84, 2);

    fp90 = fill(ax, xfill, [lb90; flipud(ub90)], [0.65 0.80 0.95], 'EdgeColor', 'none');
    fp90.FaceAlpha = 0.45;

    fp68 = fill(ax, xfill, [lb68; flipud(ub68)], [0.40 0.60 0.85], 'EdgeColor', 'none');
    fp68.FaceAlpha = 0.55;

    plot(ax, horizons, med_irf, 'Color', [0 0.4470 0.7410], 'LineWidth', 2);

    yline(ax, 0, '-', 'Color', [0.5 0.5 0.5], 'LineWidth', 0.8);

    xlabel(ax, '\textrm{Quarters}', 'FontSize', 24, 'FontName', 'Times New Roman');

    if k == 1
        ylabel(ax, '\textrm{Percent (\%)}', 'FontSize', 24, 'FontName', 'Times New Roman');
    end

    set(ax, 'Box', 'off', 'TickDir', 'out', 'Layer', 'top', ...
        'XGrid', 'off', 'YGrid', 'off', ...
        'FontSize', 20, 'FontName', 'Times New Roman', 'LineWidth', 1.0);
    xlim(ax, [0 hmax_plot]);
end

linkaxes(ax_handles, 'y');

set(ax_handles, 'XTick', 0:5:hmax_plot);
set(ax_handles, 'YTick', -5:1:5);
set(ax_handles, 'YLim',  [-5 5]);

for k = 1:2
    pos = get(ax_handles(k), 'Position');
    set(ax_handles(k), 'Position', [pos(1), pos(2)+0.13, pos(3), pos(4)-0.19]);
end

sgtitle('\textbf{Real Effective Exchange Rate}', ...
    'Interpreter', 'latex', 'FontSize', 26, 'FontName', 'Times New Roman');

for k = 1:2
    pos = get(ax_handles(k), 'Position');
    xc  = pos(1) + pos(3)/2;
    annotation(fig, 'textbox', [xc-0.15, 0.01, 0.30, 0.07], ...
        'String', panel_labels{k}, ...
        'Interpreter', 'latex', ...
        'HorizontalAlignment', 'center', ...
        'VerticalAlignment', 'middle', ...
        'EdgeColor', 'none', ...
        'FontSize', 26, ...
        'FontName', 'Times New Roman');
end

%% ── Save figure ──────────────────────────────────────────────────────────

fname = fullfile(out_dir, sprintf('IRFs_Tariff_REER_RobustnessStartDate_%s.png', anchorSet));
exportgraphics(fig, fname, 'Resolution', 300);
fprintf('Comparison figure saved to %s\n', fname);
