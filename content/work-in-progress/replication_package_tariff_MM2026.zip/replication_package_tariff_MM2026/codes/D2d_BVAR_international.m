% Identification international BVAR

clear
clc

%% ── Paths ──
codeDir = fileparts(mfilename('fullpath'));
rootDir = fileparts(codeDir);
addpath(genpath(fullfile(codeDir, 'functions')));

%% ── Data ─────────────────────────────────────────────────────────────────
datafile    = fullfile(rootDir, 'dataset', 'TariffData_CA_international.mat');
panelselect = 1:11;     % all 11 variables (order fixed in TariffData_CA_international.mat)

startYear    = 2002;
startQuarter = 1;
endYear      = 2025;
endQuarter   = 2;       % data ends at 2025Q2

%% ── Model specification ──────────────────────────────────────────────────

constant = 1;           % include constant
exog     = [];          % no additional exogenous variables
p        = 4;           % lag order (quarterly)
h        = 0;           % forecast horizon

%% ── Reduced-form prior ───────────────────────────────────────────────────

prior_settings.prior_family = 'conjugate';
prior_settings.prior        = 'flat';

%% ── Structural identification (no IRF/impact-matrix restrictions) ────────

StructuralIdentification = 'Signs/Zeros';
agnostic                 = 'irfs';

SR  = {};
ZR  = {};
NSR = {};
EBR = {};

%% ── Dominance identification settings ───────────────────────────────────
%
%  Variable order in TariffData_CA_international.mat:
%    1: log_gdp                 2: cpi                  3: log_neer
%    4: trade_balance_ngdp      5: macro_unc100         6: fed_funds
%    7: log_ea_gdp              8: ea_cpi               9: ea_euribor
%   10: weighted_tau           11: log_imp
%

h_dominance = 1;     % HD horizon
tau_idx     = 10;    % column index of weighted_tau
neer_idx    = 3;     % column index of log_neer

anchor_dates = [datenum(2018, 10, 1);
                %datenum(2019,  7, 1);
                %datenum(2019, 10, 1);
                datenum(2025,  4, 1)];

anchor_signs = [+1; +1];


%% ── Imports sign restriction ─────────────────────────────────────────────
%  After a positive tariff shock, imports should fall.  We do NOT impose this
%  contemporaneously (h=0 is left free) but require it at horizons 1..h_imp.

imp_idx        = 11;             % column index of log_imp
imp_sign_restr = -1;  % imports go opposite to the tariff shock direction
h_imp          = 2;              % apply restriction at h = 1, 2 (not h = 0)

n_bvar           = numel(panelselect);
b_sign           = zeros(n_bvar,1);
b_sign(tau_idx)  = +1;
b_tol            = 0;

%% ── Sampler settings ─────────────────────────────────────────────────────

numDesiredDraws  = 1000;
BetaSigmaTries   = 100;
Qs_per_BetaSigma = 100;
nRepsWeights     = 1000;

cumulateWhich = [];

%% ── Run ──────────────────────────────────────────────────────────────────

rng('default')
Run_SVAR_tariff_SignImports_signrestriction

%% ── Post-processing ──────────────────────────────────────────────────────

hmax_plot = 15;   % report horizons 0-15 quarters

n_vars = size(Draws_IRFs, 1);
IRF_median = median(Draws_IRFs(:,1,1:hmax_plot+1,:), 4);
IRF_q16    = quantile(Draws_IRFs(:,1,1:hmax_plot+1,:), 0.16, 4);
IRF_q84    = quantile(Draws_IRFs(:,1,1:hmax_plot+1,:), 0.84, 4);
IRF_q05    = quantile(Draws_IRFs(:,1,1:hmax_plot+1,:), 0.05, 4);
IRF_q95    = quantile(Draws_IRFs(:,1,1:hmax_plot+1,:), 0.95, 4);

fprintf('\nDone. %d admissible draws saved.\n', numSavedDraws);

%% ── Plot IRFs ────────────────────────────────────────────────────────────────

Plot_IRFs_Tariff_CA_international

%% ── Output directories ─────────────────────────────────────────────────────

shockDir  = fullfile(rootDir, 'output', 'extracted_shocks');

if ~exist(shockDir, 'dir')
    mkdir(shockDir);
end

shockFile = fullfile(shockDir, 'shocks_SignImports_international.xlsx');
shockMat  = fullfile(shockDir, 'structural_shocks_SignImports_international.mat');

%% ── Save full identification output ────────────────────────────────────────

if ~exist('lags', 'var')
    lags = p;
end

save(fullfile(shockDir, 'full_identification_output_SignImports_international.mat'), ...
    'Draws_Shocks', 'Draws_IRFs', 'dates', 'varNames', ...
    'p', 'lags', 'numSavedDraws', '-v7.3');

%% ── Export historical structural shocks for plotted tariff shock ───────────

fprintf('Exporting historical structural shocks for plotted tariff shock...\n');

% -------------------------------------------------------------------------
% 1. Identify response variable: weighted_tau
% -------------------------------------------------------------------------

tau_idx = find(strcmpi(varNames, 'weighted_tau'));

if isempty(tau_idx)
    error('Variable "weighted_tau" not found in varNames.');
end

% -------------------------------------------------------------------------
% 2. Identify structural shock column
% -------------------------------------------------------------------------

shock_idx = 1;

% -------------------------------------------------------------------------
% 3. Compute same 1pp-impact normalization used in the plotted IRF
% -------------------------------------------------------------------------

impact_draws_save = squeeze(Draws_IRFs(tau_idx, shock_idx, 1, :));
impact_med_save   = median(impact_draws_save);

if ~isfinite(impact_med_save) || abs(impact_med_save) < 1e-12
    warning('Tariff impact is zero/invalid — no 1pp normalization applied.');
    scale_save = 1;
else
    scale_save = 1 / impact_med_save;
end

% -------------------------------------------------------------------------
% 4. Stack historical structural shocks across posterior draws
% -------------------------------------------------------------------------

Nd_save = size(Draws_Shocks, 3);
T_save  = size(Draws_Shocks, 1);

tau_shocks_raw_all = squeeze(Draws_Shocks(:, shock_idx, :))';   % Nd x T

tau_shocks_1pp_all = tau_shocks_raw_all / scale_save;

% -------------------------------------------------------------------------
% 5. Posterior summaries
% -------------------------------------------------------------------------

tau_raw_median = median(tau_shocks_raw_all, 1)';
tau_raw_mean   = mean(tau_shocks_raw_all, 1)';
tau_raw_p16    = prctile(tau_shocks_raw_all, 16, 1)';
tau_raw_p84    = prctile(tau_shocks_raw_all, 84, 1)';
tau_raw_p05    = prctile(tau_shocks_raw_all,  5, 1)';
tau_raw_p95    = prctile(tau_shocks_raw_all, 95, 1)';

tau_1pp_median = median(tau_shocks_1pp_all, 1)';
tau_1pp_mean   = mean(tau_shocks_1pp_all, 1)';
tau_1pp_p16    = prctile(tau_shocks_1pp_all, 16, 1)';
tau_1pp_p84    = prctile(tau_shocks_1pp_all, 84, 1)';
tau_1pp_p05    = prctile(tau_shocks_1pp_all,  5, 1)';
tau_1pp_p95    = prctile(tau_shocks_1pp_all, 95, 1)';

% -------------------------------------------------------------------------
% 6. Build quarterly Date variable for the estimation sample
% -------------------------------------------------------------------------

if exist('lags', 'var')
    p_save = lags;
elseif exist('p', 'var')
    p_save = p;
else
    error('Neither "lags" nor "p" exists. Cannot align shock dates.');
end

if exist('dates', 'var') && numel(dates) >= p_save + T_save
    shock_dn = dates(p_save+1 : p_save+T_save);
    if isdatetime(shock_dn)
        shock_years    = year(shock_dn);
        shock_quarters = quarter(shock_dn);
    else
        shock_dn       = shock_dn(:);
        shock_years    = year(datetime(shock_dn, 'ConvertFrom','datenum'));
        shock_quarters = ceil(month(datetime(shock_dn, 'ConvertFrom','datenum')) / 3);
    end
elseif exist('sample_dates', 'var') && numel(sample_dates) >= p_save + T_save
    shock_dn = sample_dates(p_save+1 : p_save+T_save);
    shock_dn = shock_dn(:);
    shock_years    = year(datetime(shock_dn, 'ConvertFrom','datenum'));
    shock_quarters = ceil(month(datetime(shock_dn, 'ConvertFrom','datenum')) / 3);
else
    raw_years    = [];
    raw_quarters = [];
    yy = startYear;
    qq = startQuarter;
    while (yy < endYear) || (yy == endYear && qq <= endQuarter)
        raw_years    = [raw_years; yy];
        raw_quarters = [raw_quarters; qq];
        qq = qq + 1;
        if qq == 5
            qq = 1;
            yy = yy + 1;
        end
    end
    if length(raw_years) < p_save + T_save
        error('Date vector is too short: check start/end dates or lag alignment.');
    end
    shock_years    = raw_years(p_save+1 : p_save+T_save);
    shock_quarters = raw_quarters(p_save+1 : p_save+T_save);
end

Date = cell(T_save, 1);
for t = 1:T_save
    Date{t} = sprintf('%dQ%d', shock_years(t), shock_quarters(t));
end

% -------------------------------------------------------------------------
% 7. Export structural shocks
% -------------------------------------------------------------------------

T_export = table( ...
    Date, ...
    tau_1pp_median, tau_1pp_mean, ...
    tau_1pp_p16, tau_1pp_p84, ...
    tau_1pp_p05, tau_1pp_p95, ...
    'VariableNames', { ...
        'Date', 'Median', 'Mean', ...
        'P16', 'P84', 'P05', 'P95' ...
    } ...
);

writetable(T_export, shockFile, 'Sheet', 'Summary');

T_raw_export = table( ...
    Date, ...
    tau_raw_median, tau_raw_mean, ...
    tau_raw_p16, tau_raw_p84, ...
    tau_raw_p05, tau_raw_p95, ...
    'VariableNames', { ...
        'Date', 'Median', 'Mean', ...
        'P16', 'P84', 'P05', 'P95' ...
    } ...
);

writetable(T_raw_export, shockFile, 'Sheet', 'Summary_raw');

% -------------------------------------------------------------------------
% 8. Save MATLAB file
% -------------------------------------------------------------------------

save(shockMat, ...
    'tau_shocks_raw_all', ...
    'tau_shocks_1pp_all', ...
    'tau_raw_median', 'tau_raw_mean', ...
    'tau_raw_p16', 'tau_raw_p84', 'tau_raw_p05', 'tau_raw_p95', ...
    'tau_1pp_median', 'tau_1pp_mean', ...
    'tau_1pp_p16', 'tau_1pp_p84', 'tau_1pp_p05', 'tau_1pp_p95', ...
    'Date', 'shock_years', 'shock_quarters', ...
    'scale_save', 'impact_med_save', ...
    'shock_idx', 'tau_idx');

fprintf('  Saved Excel file:  %s\n', shockFile);
fprintf('  Saved MATLAB file: %s\n', shockMat);
