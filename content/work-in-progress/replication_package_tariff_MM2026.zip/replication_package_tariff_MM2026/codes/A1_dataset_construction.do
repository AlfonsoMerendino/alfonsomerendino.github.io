*===============================================================================
* A1 - Build the analysis dataset (data) from /sources
*===============================================================================

clear all
set more off

if "$dir" == "" global dir = cond(substr("`c(pwd)'",-5,5)=="codes", substr("`c(pwd)'",1,length("`c(pwd)'")-6), "`c(pwd)'")
global data    "$dir/sources"
global dataset "$dir/dataset"
global figures "$dir/output"

cd "$dir"
capture graph set window fontface "Garamond"

capture program drop save_main
program define save_main
    save "${dataset}/data.dta", replace
end
*******************************************************************
****** CPI prices: https://fred.stlouisfed.org/series/CPIAUCSL

import excel "$data/CPIAUCSL", sheet("Monthly") firstrow clear

gen long date_monthly = mofd(observation_date)
format date_monthly %tm

gen date = qofd(dofm(date_monthly))
format date %tq

collapse (mean) cpi_level = CPIAUCSL, by(date)
label var cpi_level "CPI level (quarterly avg)"

save_main

use "$dataset/data.dta", clear

tsset date
gen cpi = (cpi_level - L4.cpi_level) / L4.cpi_level * 100
label var cpi "CPI y-o-y inflation (%)"

save_main



*******************************************************************
************ GDP: https://fred.stlouisfed.org/series/GDPC1

import excel "$data/GDPC1", sheet("Quarterly") firstrow clear

gen long date_monthly = mofd(observation_date)
format date_monthly %tm

gen date = qofd(dofm(date_monthly))
format date %tq

keep date GDPC1

merge 1:1 date using "$dataset/data.dta", nogen
rename GDPC1 gdp
label var gdp "Real GDP (GDPC1)"

save_main

use "$dataset/data.dta", clear

gen log_gdp = 100*log(gdp)
label var log_gdp "Log real GDP"

save_main


**********************************************************
********** NOMINAL GDP: https://fred.stlouisfed.org/series/GDP

import excel "$data/GDP", sheet("Quarterly") firstrow clear

gen long date_monthly = mofd(observation_date)
format date_monthly %tm

gen date = qofd(dofm(date_monthly))
format date %tq

keep date GDP

merge 1:1 date using "$dataset/data.dta", nogen
rename GDP ngdp
label var ngdp "Nominal GDP (GDP, billions USD, SAAR)"

save_main

*******************************************************************
********** Exports: https://fred.stlouisfed.org/series/EXPGSC1

import excel "$data/EXPGSC1", sheet("Quarterly") firstrow clear

gen long date_monthly = mofd(observation_date)
format date_monthly %tm

gen date = qofd(dofm(date_monthly))
format date %tq

keep date EXPGSC1

merge 1:1 date using "$dataset/data.dta", nogen
rename EXPGSC1 exp
label var exp "Real exports (EXPGSC1)"

save_main

use "$dataset/data.dta", clear

gen log_exp = 100*log(exp)
label var log_exp "Log real exports"

save_main



*******************************************************************
********** Imports: https://fred.stlouisfed.org/series/IMPGSC1

import excel "$data/IMPGSC1", sheet("Quarterly") firstrow clear

gen long date_monthly = mofd(observation_date)
format date_monthly %tm

gen date = qofd(dofm(date_monthly))
format date %tq

keep date IMPGSC1

merge 1:1 date using "$dataset/data.dta", nogen
rename IMPGSC1 imp
label var imp "Real imports (IMPGSC1)"

save_main

use "$dataset/data.dta", clear

gen log_imp = 100*log(imp)
label var log_imp "Log real imports"

save_main


*******************************************************************
********** Nominal Exports: https://fred.stlouisfed.org/series/EXPGS

import excel "$data/EXPGS", sheet("Quarterly") firstrow clear

gen long date_monthly = mofd(observation_date)
format date_monthly %tm

gen date = qofd(dofm(date_monthly))
format date %tq

keep date EXPGS

merge 1:1 date using "$dataset/data.dta", nogen
rename EXPGS exp_nominal
label var exp_nominal "Nominal exports of goods and services (EXPGS, billions USD, SAAR)"

save_main

use "$dataset/data.dta", clear

gen log_exp_nominal = 100*log(exp_nominal)
label var log_exp_nominal "Log nominal exports"

save_main


*******************************************************************
********** Nominal Imports: https://fred.stlouisfed.org/series/IMPGS

import excel "$data/IMPGS", sheet("Quarterly") firstrow clear

gen long date_monthly = mofd(observation_date)
format date_monthly %tm

gen date = qofd(dofm(date_monthly))
format date %tq

keep date IMPGS

merge 1:1 date using "$dataset/data.dta", nogen
rename IMPGS imp_nominal
label var imp_nominal "Nominal imports of goods and services (IMPGS, billions USD, SAAR)"

save_main

use "$dataset/data.dta", clear

gen log_imp_nominal = 100*log(imp_nominal)
label var log_imp_nominal "Log nominal imports"

save_main


*******************************************************************
******* Federal Funds Rate: https://fred.stlouisfed.org/series/DFF

import excel "$data/DFF", sheet("Quarterly") firstrow clear

gen long date_monthly = mofd(observation_date)
format date_monthly %tm

gen date = qofd(dofm(date_monthly))
format date %tq

keep date DFF

merge 1:1 date using "$dataset/data.dta", nogen
rename DFF fed_funds
label var fed_funds "Federal funds rate"

save_main


*******************************************************************
****** 10-Year Treasury Yield: https://fred.stlouisfed.org/series/DGS10

import excel "$data/DGS10", sheet("Quarterly") firstrow clear

gen long date_monthly = mofd(observation_date)
format date_monthly %tm

gen date = qofd(dofm(date_monthly))
format date %tq

keep date DGS10

merge 1:1 date using "$dataset/data.dta", nogen
rename DGS10 treasury10y
label var treasury10y "10-Year Treasury constant maturity yield (DGS10, %)"

save_main



**********************************************************
********** NEER: https://data.bis.org/topics/EER/BIS,WS_EER,1.0/M.N.N.US

import excel "$data/bis_dp_search_export_20260408-175519", ///
    sheet("timeseries observations") cellrange(A2) clear

keep I M

gen date_d      = date(I, "YMD")
gen date_monthly = mofd(date_d)
format date_monthly %tm

gen date = qofd(dofm(date_monthly))
format date %tq

collapse (mean) neer = M, by(date)
label var neer "Nominal effective exchange rate, narrow (BIS, 2020=100)"

merge 1:1 date using "$dataset/data.dta", nogen

save_main

use "$dataset/data.dta", clear

gen log_neer = 100*log(neer)
label var log_neer "Log nominal effective exchange rate"

save_main


**********************************************************
********** REER: https://data.bis.org/topics/EER/BIS,WS_EER,1.0/M.R.N.US

import excel "$data/bis_dp_search_export_20260408-181500", ///
    sheet("timeseries observations") cellrange(A2) clear

keep I M

gen date_d       = date(I, "YMD")
gen date_monthly = mofd(date_d)
format date_monthly %tm

gen date = qofd(dofm(date_monthly))
format date %tq

collapse (mean) reer = M, by(date)
label var reer "Real effective exchange rate, narrow (BIS, 2020=100)"

merge 1:1 date using "$dataset/data.dta", nogen

save_main

use "$dataset/data.dta", clear

gen log_reer = 100*log(reer)
label var log_reer "Log real effective exchange rate"

save_main


**********************************************************
********** CUSTOM DUTIES: https://fred.stlouisfed.org/series/B235RC1Q027SBEA

import excel "$data/B235RC1Q027SBEA", sheet("Quarterly") firstrow clear

gen long date_monthly = mofd(observation_date)
format date_monthly %tm

gen date = qofd(dofm(date_monthly))
format date %tq

keep date B235RC1Q027SBEA

merge 1:1 date using "$dataset/data.dta", nogen
rename B235RC1Q027SBEA custom_duties
label var custom_duties "Customs duties (B235RC1Q027SBEA, billions USD)"

save_main


**********************************************************
********** IMPORTS OF GOODS: https://fred.stlouisfed.org/series/A255RC1Q027SBEA

import excel "$data/A255RC1Q027SBEA", sheet("Quarterly") firstrow clear

gen long date_monthly = mofd(observation_date)
format date_monthly %tm

gen date = qofd(dofm(date_monthly))
format date %tq

keep date A255RC1Q027SBEA

merge 1:1 date using "$dataset/data.dta", nogen
rename A255RC1Q027SBEA imp_bea
label var imp_bea "Imports of goods and services, nominal (A255RC1Q027SBEA, billions USD)"

save_main



**********************************************************
********** WEIGHTED TARIFF RATE (COMPUTED)
* weighted_tau = customs duties (B235RC1Q027SBEA) / dutiable imports
* dutiable imports = all goods imports (A255RC1Q027SBEA) x quarterly share of
*   dutiable over total imports (DataWeb monthly data, summed to quarterly)

// --- Build quarterly dutiable share from DataWeb ---
import excel "$data/DataWeb-Query-Export.xlsx", sheet("Query Results") clear
keep if A == "Customs Value" | A == "Dutiable Value"
rename (A B C D) (data_type year month value)
destring year month value, replace force

// Build quarterly date from year-month
gen date_monthly = ym(year, month)
format date_monthly %tm
gen date = qofd(dofm(date_monthly))
format date %tq

// Sum monthly values to quarterly within each data type
collapse (sum) value, by(date data_type)

gen is_dutiable = (data_type == "Dutiable Value")
drop data_type
reshape wide value, i(date) j(is_dutiable)
rename (value0 value1) (customs_val dutiable_val)

gen dutiable_share = dutiable_val / customs_val
keep date dutiable_share
sort date

tempfile dataweb
save `dataweb'

// --- Merge share and compute weighted_tau2 ---
use "$dataset/data.dta", clear

merge 1:1 date using `dataweb', nogen keep(master match)

gen weighted_tau = (custom_duties / (imp_bea * dutiable_share)) * 100
label var weighted_tau "Weighted tariff rate, computed: customs duties / dutiable imports (%)"

drop dutiable_share

save_main


**********************************************************
********** TRADE RESTRICTIVENESS INDEX

import excel "$data/tau_tri_tauF2025update", sheet("Sheet1") cellrange(A2) clear

keep A C
rename A date_raw
rename C tri

gen year    = floor(date_raw)
gen quarter = round((date_raw - floor(date_raw)) * 4) + 1
gen date    = yq(year, quarter)
format date %tq
drop date_raw year quarter

label var tri "Trade restrictiveness index (tri_t)"

merge 1:1 date using "$dataset/data.dta", nogen

* Normalise tri to weighted_tau scale (1990q1-2025q3)
quietly sum tri         if inrange(date, tq(1990q1), tq(2025q3))
local sd_tri = r(sd)
quietly sum weighted_tau if inrange(date, tq(1990q1), tq(2025q3))
local sd_wt  = r(sd)

cap drop norm_tri 
gen norm_tri = tri / `sd_tri' * `sd_wt'
label var norm_tri "TRI rescaled to weighted_tau sd (1990q1-2025q3)"

save_main


**********************************************************
********** GROSS PRIVATE DOMESTIC INVESTMENT: https://fred.stlouisfed.org/series/GPDIC1

import excel "$data/GPDIC1", sheet("Quarterly") firstrow clear

gen long date_monthly = mofd(observation_date)
format date_monthly %tm

gen date = qofd(dofm(date_monthly))
format date %tq

keep date GPDIC1

merge 1:1 date using "$dataset/data.dta", nogen
rename GPDIC1 invest
label var invest "Real gross private domestic investment (GPDIC1)"

save_main

use "$dataset/data.dta", clear

gen log_invest = 100*log(invest)
label var log_invest "Log real gross private domestic investment"

save_main



**********************************************************
********** TRADE POLICY UNCERTAINTY (QUARTERLY): https://www.policyuncertainty.com/trade_cimpr.html

import excel "$data/tpu_web_latest", sheet("TPU_QUARTERLY") firstrow clear

rename DATEQ date_str
gen date = quarterly(date_str, "YQ")
format date %tq
drop date_str

keep date TPUQ

merge 1:1 date using "$dataset/data.dta", nogen
rename TPUQ tpu
label var tpu "Trade policy uncertainty index, quarterly (TPUQ)"

save_main

use "$dataset/data.dta", clear

gen log_tpu = 100*log(tpu)
label var log_tpu "Log trade policy uncertainty index"

save_main


**********************************************************
********** MACRO UNCERTAINTY (h=12): https://www.sydneyludvigson.com/macro-and-financial-uncertainty-indexes

import excel "$data/MacroUncertaintyToCirculate", ///
    sheet("Macro Uncertainty") cellrange(A2) clear

* Column A = date (monthly), Column D = h=12
keep A D
rename A obs_date
rename D macro_unc

gen date_monthly = mofd(obs_date)
format date_monthly %tm

gen date = qofd(dofm(date_monthly))
format date %tq
drop obs_date date_monthly

collapse (mean) macro_unc, by(date)
label var macro_unc "Macro uncertainty, h=12 (quarterly avg)"

gen macro_unc100 = macro_unc * 100
label var macro_unc100 "Macro uncertainty, h=12 x100 (quarterly avg)"

merge 1:1 date using "$dataset/data.dta", nogen

save_main


**********************************************************
********** CURRENT ACCOUNT BALANCE (BEA, billions USD)

import excel "$data/current_account.xlsx", firstrow clear

rename date date_str
gen date = quarterly(date_str, "YQ")
format date %tq
drop date_str

label var current_account "Current account balance (BEA, billions USD, SA)"

merge 1:1 date using "$dataset/data.dta", nogen

save_main











**********************************************************
********** CURRENT ACCOUNT / NOMINAL GDP
**********************************************************

use "$dataset/data.dta", clear

capture drop current_account_ngdp
gen current_account_ngdp = 100 * current_account / ngdp
label var current_account_ngdp "Current account balance (% of nominal GDP)"

save_main


**********************************************************
********** TRADE WEIGHTED TARIFF RATE SGU: tau_tri_tauF2025update.xlsx

import excel "$data/tau_tri_tauF2025update.xlsx", sheet("Sheet1") cellrange(A2) clear

* Column A = decimal date (1959.00=q1, 1959.25=q2, ...), Column B = tau_t
keep A B
rename A date_raw
rename B weighted_tau_SGU

gen year    = floor(date_raw)
gen quarter = round((date_raw - floor(date_raw)) * 4) + 1
gen date    = yq(year, quarter)
format date %tq
drop date_raw year quarter

label var weighted_tau_SGU "Trade-weighted import tariff rate, tau_t (SGU 2025 update)"

merge 1:1 date using "$dataset/data.dta", nogen

save_main



**********************************************************
********** EURO AREA SERIES
********** Sources:
**********  - sources/Euro_Area_monthly_dataset_2002_2025.xlsx   (monthly: CPI, IP)
**********  - sources/ECB Data Portal_20260526153504.csv          (monthly: 3M Euribor, FM.M.U2.EUR.RT.MM.EURIBOR3MD_.HSTA)
**********  - sources/CLV10MNACB1GQSCAEA20Q.xlsx                 (quarterly: EA real GDP, FRED CLV10MNACB1GQSCAEA20Q)
**********      https://fred.stlouisfed.org/series/CLV10MNACB1GQSCAEA20Q
**********  - sources/CPMNACB1GQSCAEA20Q.xlsx                    (quarterly: EA nominal GDP, FRED CPMNACB1GQSCAEA20Q)
**********      https://fred.stlouisfed.org/series/CPMNACB1GQSCAEA20Q
**********************************************************

* --- Monthly EA series collapsed to quarterly averages ---
import excel "$data/Euro_Area_monthly_dataset_2002_2025.xlsx", sheet("Sheet1") firstrow clear

* date_monthly is a string like "2002m1"
rename date_monthly date_str
gen date_monthly = monthly(date_str, "YM")
format date_monthly %tm
drop date_str

gen date = qofd(dofm(date_monthly))
format date %tq

collapse (mean) ea_cpi = I10_CPI ea_indprod = I10_INDPROD, by(date)

label var ea_cpi      "Euro area CPI inflation (I10_CPI, quarterly avg)"
label var ea_indprod  "Euro area industrial production (I10_INDPROD, quarterly avg)"

merge 1:1 date using "$dataset/data.dta", nogen

save_main

use "$dataset/data.dta", clear

cap drop log_ea_indprod
gen log_ea_indprod = 100*log(ea_indprod)
label var log_ea_indprod "Log Euro area industrial production"

save_main


* --- EA 3-month Euribor (ECB FM.M.U2.EUR.RT.MM.EURIBOR3MD_.HSTA), monthly -> quarterly avg ---
import delimited "$data/ECB Data Portal_20260526153504.csv", varnames(1) clear

* Columns in order: DATE (M/D/YYYY), TIME PERIOD (e.g. "1994Jan"), <long-named euribor series>
ds
local vars `r(varlist)'
local datevar : word 1 of `vars'
local valvar  : word 3 of `vars'

keep `datevar' `valvar'
rename `datevar' date_str
rename `valvar'  ea_euribor
destring ea_euribor, replace force

gen date_d = date(date_str, "MDY")
format date_d %td
gen date_monthly = mofd(date_d)
format date_monthly %tm

gen date = qofd(dofm(date_monthly))
format date %tq

collapse (mean) ea_euribor, by(date)
label var ea_euribor "Euro area 3-month Euribor (ECB FM.M.U2.EUR.RT.MM.EURIBOR3MD_.HSTA, quarterly avg, %)"

merge 1:1 date using "$dataset/data.dta", nogen

save_main


* --- EA real GDP: https://fred.stlouisfed.org/series/CLV10MNACB1GQSCAEA20Q ---
*     (chain-linked volumes, millions EUR, SA)
import excel "$data/CLV10MNACB1GQSCAEA20Q", sheet("Quarterly") firstrow clear

gen long date_monthly = mofd(observation_date)
format date_monthly %tm

gen date = qofd(dofm(date_monthly))
format date %tq

keep date CLV10MNACB1GQSCAEA20Q

merge 1:1 date using "$dataset/data.dta", nogen
cap drop ea_gdp
rename CLV10MNACB1GQSCAEA20Q ea_gdp
label var ea_gdp "EA real GDP (FRED CLV10MNACB1GQSCAEA20Q, chain-linked vol., mn EUR, SA)"

save_main

use "$dataset/data.dta", clear

cap drop log_ea_gdp
gen log_ea_gdp = 100*log(ea_gdp)
label var log_ea_gdp "Log EA real GDP (CLV10MNACB1GQSCAEA20Q)"

save_main


* --- EA nominal GDP: https://fred.stlouisfed.org/series/CPMNACB1GQSCAEA20Q ---
*     (current prices, millions EUR, SA)
import excel "$data/CPMNACB1GQSCAEA20Q", sheet("Quarterly") firstrow clear

gen long date_monthly = mofd(observation_date)
format date_monthly %tm

gen date = qofd(dofm(date_monthly))
format date %tq

keep date CPMNACB1GQSCAEA20Q

merge 1:1 date using "$dataset/data.dta", nogen
cap drop ea_ngdp
rename CPMNACB1GQSCAEA20Q ea_ngdp
label var ea_ngdp "EA nominal GDP (FRED CPMNACB1GQSCAEA20Q, current prices, mn EUR, SA)"

save_main

use "$dataset/data.dta", clear

cap drop log_ea_ngdp
gen log_ea_ngdp = 100*log(ea_ngdp)
label var log_ea_ngdp "Log EA nominal GDP (CPMNACB1GQSCAEA20Q)"

save_main


*--------------------------------------------------------*
* Export: prepend safe string date column for MATLAB
*--------------------------------------------------------*
capture shell taskkill /f /im EXCEL.EXE

capture drop qdate_export date_str
gen double qdate_export = .

local datefmt : format date

if strpos("`datefmt'", "%tq") {
    replace qdate_export = date
}
else if strpos("`datefmt'", "%td") {
    replace qdate_export = qofd(date)
}
else if strpos("`datefmt'", "%tc") {
    replace qdate_export = qofd(dofc(date))
}
else {
    quietly summarize date, meanonly

    if abs(r(max)) > 1e7 {
        replace qdate_export = qofd(dofc(date))   // datetime
    }
    else if abs(r(max)) > 1000 {
        replace qdate_export = qofd(date)         // daily date
    }
    else {
        replace qdate_export = date               // already quarterly
    }
}

format qdate_export %tq

gen str10 date_str = string(qdate_export, "%tq")
order date_str, first


keep if inrange(qdate, tq(1990q1), tq(2025q4))
save_main

export excel "$dataset/data.xlsx", firstrow(variables) replace

drop date_str qdate_export

