*=============================================================================*
* Plots z(tau_s_fullcalib) and z(weighted_tau) from data.dta.
*
*   z(weighted_tau)     -- blue, dashed  : Tariff rate
*   z(tau_s_fullcalib)  -- orange, solid : Structural trade policy stance
*
* Both series are standardized on the common plotted sample: 1990Q1-2025Q4.
*=============================================================================*

clear all
set more off

if "$dir" == "" global dir = cond(substr("`c(pwd)'",-5,5)=="codes", substr("`c(pwd)'",1,length("`c(pwd)'")-6), "`c(pwd)'")
global dataset "$dir/dataset"
global figures "$dir/output"

capture graph set window fontface "Garamond"
capture graph drop _all

use "$dataset/data.dta", clear

keep if inrange(date, tq(1990q1), tq(2025q4))

********************************************************************************
* Standardize variables on common plotted sample: 1990Q1-2025Q4
********************************************************************************

cap drop z_tau_s_fullcalib z_weighted_tau

egen z_tau_s_fullcalib = std(tau_s_fullcalib) ///
    if inrange(date, tq(1990q1), tq(2025q4)) ///
    & !missing(tau_s_fullcalib, weighted_tau)

egen z_weighted_tau = std(weighted_tau) ///
    if inrange(date, tq(1990q1), tq(2025q4)) ///
    & !missing(tau_s_fullcalib, weighted_tau)

********************************************************************************
* Y range of the graph: use both standardized plotted series
********************************************************************************

quietly summarize z_weighted_tau ///
    if !missing(z_weighted_tau, z_tau_s_fullcalib), meanonly

local ymin = r(min)
local ymax = r(max)

quietly summarize z_tau_s_fullcalib ///
    if !missing(z_weighted_tau, z_tau_s_fullcalib), meanonly

local ymin = min(`ymin', r(min))
local ymax = max(`ymax', r(max))

* Small margins
local yrange = `ymax' - `ymin'
local ymin_plot = `ymin' - 0.05*`yrange'
local ymax_plot = `ymax' + 0.05*`yrange'

* Clean lower bound
local ymin_plot = min(-2, `ymin_plot')

sort date

********************************************************************************
* Figure
********************************************************************************

twoway ///
    (line z_weighted_tau date, ///
        lpattern(dash) ///
        lcolor("0 112 188") ///
        lwidth(thick)) ///
    (line z_tau_s_fullcalib date, ///
        lpattern(solid) ///
        lcolor("216 78 19") ///
        lwidth(thick)) ///
    , ///
    legend(order( 2 "Structural tariff" 1 "Tariff rate") ///
           cols(2) ///
           ring(1) ///
           pos(6) ///
           size(6) ///
           region(lcolor(black) lwidth(thin) fcolor(white))) ///
    yline(0, lcolor(black) lpattern(dash) lwidth(thin)) ///
    ytitle("Struct. vs Obs. Tariffs (std.)", size(7)) ///
    ylabel(, angle(0) nogrid noticks labsize(6.7)) ///
    yscale(range(`ymin_plot' `ymax_plot')) ///
    xtitle("") ///
    xlabel(`=tq(1990q1)' `=tq(1996q1)' `=tq(2002q1)' ///
           `=tq(2008q1)' `=tq(2014q1)' `=tq(2020q1)' ///
           `=tq(2025q1)', ///
        format(%tqCY) nogrid noticks labsize(6.7)) ///
    xscale(range(`=tq(1990q1)' `=tq(2025q4)')) ///
    ysize(4.2) ///
    xsize(8.8) ///
    graphregion(color(white)) ///
    plotregion(color(white) margin(small)) ///
    bgcolor(white) ///
    name(tau_s_weighted_tau_1990, replace)

graph export "$figures/z_tau_s_fullcalib_z_weighted_tau_1990.png", ///
    replace width(2600) height(1250)
