close all; clear all; clc

codeDir = fileparts(mfilename('fullpath'));
rootDir = fileparts(codeDir);
addpath(fullfile(codeDir, 'functions_caldara'));

rho_tau=0.99; sigmabar=-6.14; rho_sigma=0.96; eta=0.37;
[rs,rt,et,sb]=par_transform_AR1(rho_sigma,rho_tau,eta,sigmabar);
theta=[rs,rt,et,sb];
N=250000; R=6;

outdir = fullfile(rootDir, 'dataset');
if ~exist(outdir,'dir'); mkdir(outdir); end

%% ------------------------------- data ----------------------------------
Tab  = readtable(fullfile(rootDir,'dataset','data.xlsx'),'VariableNamingRule','preserve');
dt   = datetime(Tab.date);
dstr = Tab.date_str;
wt1  = Tab.weighted_tau;
STPU = Tab.struct_tpu_sv_fullcalib;

assert(~any(isnan(wt1)), ...
    'weighted_tau (WIT1) has missing values; the particle filter needs a gap-free series.');

fprintf('WIT1: %s to %s (T=%d), no missing values\n', ...
    datestr(dt(1),'yyyyQQ'),datestr(dt(end),'yyyyQQ'),numel(wt1));

tau1 = wt1/100;      % WIT1, fraction

%% ------------------------------ filter ---------------------------------
fprintf('filtering WIT1 (N=%d, %d runs) ...\n',N,R);
[sv1,sd1] = filt_avg(theta,tau1,N,R,900);
fprintf('  WIT1 across-run s.d.: pre-2025 max %.4f | 2025 max %.4f\n', ...
    max(sd1(year(dt)<2025)),max(sd1(year(dt)==2025)));

%% ------------------------- correlations --------------------------------
pre = year(dt)<2025;
fprintf('\n=== correlations with STPU ===\n');
fprintf('%-28s %10s %10s %12s\n','','full 90-25','pre-2025','d(levels) full');
fprintf('%-28s %10.4f %10.4f %12.4f\n','Caldara SV on WIT1', ...
    corr_(sv1,STPU),corr_(sv1(pre),STPU(pre)),corr_(diff(sv1),diff(STPU)));

fprintf('\n=== peaks ===\n');
[m1,i1]=max(sv1); [ms,is]=max(STPU);
fprintf('SV WIT1 max %7.3f at %s | STPU max %7.4f at %s\n', ...
    m1,dstr{i1},ms,dstr{is});
fprintf('STPU 2019q4 %.4f 2020q1 %.4f | 2025q2 %.4f 2025q4 %.4f\n', ...
    STPU(strcmp(dstr,'2019q4')),STPU(strcmp(dstr,'2020q1')), ...
    STPU(strcmp(dstr,'2025q2')),STPU(strcmp(dstr,'2025q4')));
fprintf('SV WIT1 2019q4 %.3f 2020q1 %.3f | 2025q2 %.3f 2025q4 %.3f\n', ...
    sv1(strcmp(dstr,'2019q4')),sv1(strcmp(dstr,'2020q1')), ...
    sv1(strcmp(dstr,'2025q2')),sv1(strcmp(dstr,'2025q4')));

%% ------------------------------ export ---------------------------------
out = table(dt,dstr,100*tau1,sv1,sd1,STPU, ...
  'VariableNames',{'date','date_str','WIT1_pct','sv_WIT1_pctpts','sv_WIT1_mcsd','STPU'});
writetable(out,fullfile(outdir,'SV_WIT1_STPU.csv'));
save(fullfile(outdir,'SV_WIT1_STPU.mat'),'out','dt','dstr','sv1','sd1', ...
     'STPU','tau1','rho_tau','sigmabar','rho_sigma','eta','N','R');
fprintf('\ndata written to %s\n',outdir);
fprintf('DONE\n');

%% ------------------------------ helper ---------------------------------
function [m,s] = filt_avg(theta,y,N,R,seed0)
    M = zeros(numel(y),R);
    for r=1:R
        rng(seed0+r); S=tempname;
        PF_caller(theta,y,N,10,1,S);
        L=load(S,'x_resampled_store');
        M(:,r)=median(squeeze(100*exp(L.x_resampled_store))',2);
        delete([S '.mat']);
    end
    m=mean(M,2); s=std(M,0,2);
end

function r = corr_(x,y)
    c = corrcoef(x,y);
    r = c(1,2);
end
