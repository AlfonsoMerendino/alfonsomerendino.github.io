%% S-TPU SV -- FULLY CALIBRATED
%   Model: 2-component tau_M = tau_s + tau_m.
%   All 8 parameters FIXED at the calibration values below:
%       rho_sigS = 0.950    rho_sigT = 0.500
%       rho_S    = 0.975    rho_M    = 0.200
%       eta_S    = 0.250    eta_T    = 0.900
%       sigSbar  = -2.00    sigTbar  = -2.00
%   No MCMC. One bootstrap-PF likelihood pass on the estimation window
%   (rng(1), N=100000) and one BP-style filter pass over the full sample
%   (rng(2), N=100000).
%   Sample (estimation + filter): 1990q1 - 2025q4.

clear all; close all; clc
rng default
rng(1)

set(groot,'defaultAxesTickLabelInterpreter','latex');
set(groot,'defaulttextinterpreter','latex');
set(groot,'defaultLegendInterpreter','latex');

%% -- Run mode + paths ------------------------------------------------
codeDir       = fileparts(mfilename('fullpath'));
if isempty(codeDir); codeDir = pwd; end
datafile_xlsx = fullfile(codeDir, '..', 'dataset', 'data.xlsx');
resultsDir    = fullfile(codeDir, '..', 'dataset',     'output_stpu_sv_FULLCALIB');
figDir        = fullfile(codeDir, '..', 'output', 'output_stpu_sv_FULLCALIB');

if ~isfolder(resultsDir); mkdir(resultsDir); end
if ~isfolder(figDir);     mkdir(figDir);     end
assert(isfile(datafile_xlsx), 'data.xlsx not found at %s', datafile_xlsx);

%% -- Sample periods ---------------------------------------------------
smplStart   = "1990q1";
smplEnd_est = "2025q4";
smplEnd     = "2025q4";

%% -- Load data (full window through smplEnd) --------------------------
T = readtable(datafile_xlsx);

if ~ismember('date_str', T.Properties.VariableNames)
    assert(ismember('date', T.Properties.VariableNames), ...
        'Neither date_str nor date column found in data.xlsx');
    d = T.date;
    if ~isdatetime(d)
        d = datetime(d, 'ConvertFrom', 'datenum');
    end
    yy_ = year(d);
    qq_ = floor((month(d)-1)/3) + 1;
    T.date_str = compose("%dq%d", yy_, qq_);
end

needed = {'date_str','weighted_tau','tpu'};
for k = 1:numel(needed)
    assert(ismember(needed{k}, T.Properties.VariableNames), ...
        'Missing column %s in data.xlsx', needed{k});
end

date_str = string(T.date_str);

sort_ord = sortrows([(1:numel(date_str)).', ...
                     double(extractBefore(date_str,"q")), ...
                     double(extractAfter(date_str,"q"))], [2 3]);
T        = T(sort_ord(:,1), :);
date_str = string(T.date_str);
iStart = find(date_str == smplStart, 1, 'first');
if isempty(iStart)
    warning('smplStart=%s not in data.xlsx; clipping to first available date %s.', smplStart, date_str(1));
    iStart    = 1;
    smplStart = date_str(1);
end
iEnd = find(date_str == smplEnd, 1, 'first');
if isempty(iEnd)
    warning('smplEnd=%s not in data.xlsx; clipping to last available date %s.', smplEnd, date_str(end));
    iEnd    = numel(date_str);
    smplEnd = date_str(end);
end

tau_raw  = T.weighted_tau(iStart:iEnd);
tpu_raw  = T.tpu(iStart:iEnd);
dstr     = date_str(iStart:iEnd);

valid    = ~isnan(tau_raw);
tau_raw  = tau_raw(valid);
tpu_raw  = tpu_raw(valid);
dstr     = dstr(valid);

yy = double(extractBefore(dstr, "q"));
qq = double(extractAfter(dstr,  "q"));
mm = 3*(qq-1) + 1;
dates_dt = datetime(yy, mm, 1);

i_est = find(dstr == smplEnd_est, 1, 'first');
if isempty(i_est)
    warning('smplEnd_est=%s not found; clipping to last available date %s.', smplEnd_est, dstr(end));
    i_est       = numel(dstr);
    smplEnd_est = dstr(end);
end
est_idx = 1:i_est;

fprintf('\nFull sample: %s -- %s (T = %d). Estimation window: %s -- %s (T = %d).\n', ...
    smplStart, smplEnd, numel(tau_raw), smplStart, smplEnd_est, numel(est_idx));

%% -- Standardise using the estimation-window moments -----------------
tau_mean  = mean(tau_raw(est_idx));   tau_sd  = std(tau_raw(est_idx));
tpu_mean  = mean(tpu_raw(est_idx),  'omitnan'); tpu_sd  = std(tpu_raw(est_idx),  'omitnan');

tau_z  = (tau_raw  - tau_mean ) / tau_sd;
tpu_z  = (tpu_raw  - tpu_mean ) / tpu_sd;

y_obs_full = tau_z;
y_obs_est  = y_obs_full(est_idx, :);
Tobs_full  = size(y_obs_full, 1);
Tobs_est   = size(y_obs_est, 1);
Tobs       = Tobs_full;

%% -- Filter settings: no MCMC, fully calibrated -----------------------
num_particles  = 100000;
num_part_final = 100000;

%% -- Parameters: all FIXED -------------------------------------------
FIX_rho_sigS = 0.950;
FIX_rho_sigT = 0.500;
FIX_rho_S    = 0.975;
FIX_rho_M    = 0.200;
FIX_eta_S    = 0.250;
FIX_eta_T    = 0.900;

% Fixed long-run log-SD means: theta = [sigSbar; sigTbar]
theta_calib = [ ...
   -2.0;    % sigSbar
   -2.0];   % sigTbar

par_names = {'sigSbar','sigTbar'};
theta_post_med = theta_calib;
fname_final = fullfile(resultsDir, 'STPU_SV_FULLCALIB_results.mat');

%% -- Likelihood diagnostic at calibrated theta -----------------------
rng(1)
[logL_calib, ~] = pf_loglik_v1CALIB(theta_calib, y_obs_est, num_particles, 0);
fprintf('\nFully calibrated run. theta = [sigSbar; sigTbar] = [%.2f; %.2f].\n', ...
        theta_calib(1), theta_calib(2));
fprintf('PF log-likelihood on estimation window at calibrated theta = %.4f\n', logL_calib);

save(fname_final, ...
    'theta_calib','theta_post_med','par_names', ...
    'FIX_rho_sigS','FIX_rho_sigT','FIX_rho_S','FIX_rho_M','FIX_eta_S','FIX_eta_T', ...
    'num_particles','num_part_final','logL_calib', ...
    'tau_mean','tau_sd','tpu_mean','tpu_sd', ...
    'dates_dt','dstr','tau_raw','tpu_raw', ...
    'tau_z','tpu_z','y_obs_full','y_obs_est', ...
    'smplStart','smplEnd','smplEnd_est','est_idx','-v7.3');

%% -- Single PF filter at calibrated theta (BP-EXACT) ----------------
fprintf('\nSingle PF filter at calibrated theta (N=%d particles, BP-exact median) ...\n', num_part_final);
rng(2)
[~, fl_med] = pf_loglik_v1CALIB(theta_calib, y_obs_full, num_part_final, 1);

% BP filtered point estimates (MEDIAN across resampled particles)
tau_s_filt = fl_med.x_med(:,1);
sig_S_filt = fl_med.x_med(:,2);               % BP filtered sig_S
sig_T_filt = fl_med.x_med(:,3);               % BP filtered sig_T

% BP 95% bands (2.5 / 97.5 percentiles across resampled particles)
sig_S_p025 = fl_med.x_p025(:,2);  sig_S_p975 = fl_med.x_p975(:,2);
sig_T_p025 = fl_med.x_p025(:,3);  sig_T_p975 = fl_med.x_p975(:,3);

% Derived vol-units series (exp(.) of BP filtered sig)
tau_sd2    = tau_sd^2;
sd_S_filt  = exp(sig_S_filt) * tau_sd;
sd_T_filt  = exp(sig_T_filt) * tau_sd;
STPU       = exp(2*sig_S_filt) * tau_sd2;
trans_var  = exp(2*sig_T_filt) * tau_sd2;
total_var  = STPU + trans_var;

% Variance-units 95% bands (LEVEL units)
STPU_p025      = exp(2*sig_S_p025) * tau_sd2;  STPU_p975      = exp(2*sig_S_p975) * tau_sd2;
trans_var_p025 = exp(2*sig_T_p025) * tau_sd2;  trans_var_p975 = exp(2*sig_T_p975) * tau_sd2;

ESS_filt = fl_med.ESS;
fprintf('Single-filter done (BP-exact median). min ESS=%.0f (of %d particles).\n', min(ESS_filt(2:end)), num_part_final);

%% -- Save outputs --
outTbl = table();
outTbl.date        = dates_dt;
outTbl.date_str    = dstr;
outTbl.tau_raw     = tau_raw;
outTbl.tau_z       = tau_z;
outTbl.tpu_raw     = tpu_raw;
outTbl.tpu_z       = tpu_z;
outTbl.tau_s_filt   = tau_s_filt;       % BP: median(tau_s_resampled)
outTbl.sig_S_filt   = sig_S_filt;       % BP: median(sig_S_resampled)   (log-SD)
outTbl.sig_S_p025   = sig_S_p025;       % BP: 2.5%  quantile across resampled
outTbl.sig_S_p975   = sig_S_p975;       % BP: 97.5% quantile across resampled
outTbl.sig_T_filt   = sig_T_filt;       % BP: median(sig_T_resampled)
outTbl.sig_T_p025   = sig_T_p025;
outTbl.sig_T_p975   = sig_T_p975;
outTbl.sd_S_filt    = sd_S_filt;
outTbl.sd_T_filt    = sd_T_filt;
outTbl.STPU         = STPU;             % exp(2*sig_S_filt)
outTbl.STPU_p025    = STPU_p025;        % exp(2*sig_S_p025)
outTbl.STPU_p975    = STPU_p975;
outTbl.trans_var    = trans_var;
outTbl.trans_p025   = trans_var_p025;
outTbl.trans_p975   = trans_var_p975;
outTbl.total_var    = total_var;
outTbl.ESS_filt     = ESS_filt;

csvOut       = fullfile(resultsDir, 'STPU_SV_FULLCALIB_series.csv');
xlsxOut      = fullfile(resultsDir, 'STPU_SV_FULLCALIB_series.xlsx');
xlsxOut_main = fullfile(resultsDir, 'STPU_SV_FULLCALIB_STPU_index.xlsx');
writetable(outTbl, csvOut);
writetable(outTbl, xlsxOut);
writetable(table(dstr, sig_S_filt, sig_S_p025, sig_S_p975, sig_T_filt, sd_S_filt, sd_T_filt, ...
                 STPU, STPU_p025, STPU_p975, trans_var, total_var, ...
    'VariableNames', {'date_str','sig_S_filt','sig_S_p025','sig_S_p975','sig_T_filt', ...
                      'sd_S_filt','sd_T_filt','STPU','STPU_p025','STPU_p975', ...
                      'trans_var','total_var'}), xlsxOut_main);

save(fname_final, ...
    'sig_S_filt','sig_S_p025','sig_S_p975', ...
    'sig_T_filt','sig_T_p025','sig_T_p975', ...
    'sd_S_filt','sd_T_filt', ...
    'STPU','STPU_p025','STPU_p975', ...
    'trans_var','trans_var_p025','trans_var_p975', ...
    'total_var','tau_s_filt','ESS_filt', ...
    'theta_calib','theta_post_med','outTbl','-append');

fprintf('\nSaved: %s\n        %s\n        %s\n', csvOut, xlsxOut, xlsxOut_main);

%% -- Plots --
figure('Name','S-TPU SV v14 FULLCALIB (BP single filter @ calibrated theta)','Color','w','Position',[100 100 1200 950])

subplot(4,1,1)
plot(dates_dt, tau_z, 'k-', 'LineWidth', 0.9); hold on
plot(dates_dt, tau_s_filt, 'r-', 'LineWidth', 1.1)
grid on; axis tight
title('$\tau_M$ (std.) and filtered $\tau^s_t$ at calibrated $\theta$', 'Interpreter','latex')
legend('$\tau_M$','$\tau^s_{t|t}$','Location','best')

subplot(4,1,2)
plot(dates_dt, sig_S_filt, 'r-', 'LineWidth', 1.3); hold on
plot(dates_dt, sig_T_filt, 'b-', 'LineWidth', 1.3)
grid on; axis tight
title('BP filtered log-SDs $\sigma_{S,t|t}$ (red), $\sigma_{T,t|t}$ (blue)', 'Interpreter','latex')
legend('$\sigma_S$','$\sigma_T$','Location','best')

subplot(4,1,3)
plot(dates_dt, sd_S_filt, 'r-', 'LineWidth', 1.3); hold on
plot(dates_dt, sd_T_filt, 'b-', 'LineWidth', 1.3)
grid on; axis tight
title('Derived SDs $\exp(\sigma_{S,t|t})$, $\exp(\sigma_{T,t|t})$', 'Interpreter','latex')
legend('$\exp(\sigma_S)$','$\exp(\sigma_T)$','Location','best')

subplot(4,1,4)
plot(dates_dt, STPU, 'r-', 'LineWidth', 1.3); hold on
plot(dates_dt, trans_var, 'b-', 'LineWidth', 1.3)
plot(dates_dt, total_var, 'k--', 'LineWidth', 1.0)
grid on; axis tight
title('STPU $=\exp(2\sigma_S)$, trans $=\exp(2\sigma_T)$, total', 'Interpreter','latex')
legend('STPU','trans','total','Location','best')

fprintf('\nDone (v14 FULLCALIB, single-filter @ calibrated theta).\n');


%% =====================================================================
%  LOCAL FUNCTIONS
%% =====================================================================

function [logL, filt] = pf_loglik_v1CALIB(theta, y, N, store_level)
%  Fully calibrated bootstrap PF for the 2-component AR(1)-SV system.

    if nargin < 4; store_level = 0; end

    % FIXED CALIBRATION VALUES
    rho_sigS = 0.950;
    rho_sigT = 0.500;
    rho_S    = 0.975;
    rho_M    = 0.200;
    eta_S    = 0.250;
    eta_T    = 0.900;


    % Fixed long-run log-SD means supplied by theta_calib.
    sigSbar  = theta(1);
    sigTbar  = theta(2);

    T = size(y,1);

    % --- Initial particles (stationary draw of the SV states) ---
    if abs(rho_sigS) < 1
        sdS = eta_S / sqrt(max(1-rho_sigS^2, 1e-8));
    else
        sdS = eta_S;
    end
    if abs(rho_sigT) < 1
        sdT = eta_T / sqrt(max(1-rho_sigT^2, 1e-8));
    else
        sdT = eta_T;
    end
    sig_S = sigSbar + sdS * randn(N,1);   % log-SD (initial)
    sig_T = sigTbar + sdT * randn(N,1);   % log-SD (initial)

    % Per-particle stationary draw of tau_s using each particle's initial sig_S
    if abs(rho_S) < 1
        sd_taus0 = exp(sig_S) ./ sqrt(max(1-rho_S^2, 1e-8));
    else
        sd_taus0 = exp(sig_S);
    end
    tau_s = sd_taus0 .* randn(N,1);

    % Per-particle stationary draw of tau_m using each particle's initial sig_T
    if abs(rho_M) < 1
        sd_taum0 = exp(sig_T) ./ sqrt(max(1-rho_M^2, 1e-8));
    else
        sd_taum0 = exp(sig_T);
    end
    tau_m_prev = sd_taum0 .* randn(N,1);

    logL    = 0;
    log_2pi = log(2*pi);
    ESS = zeros(T,1);
    if store_level >= 1
        x_med   = zeros(T,3);
        x_p025  = zeros(T,3);
        x_p975  = zeros(T,3);
    end

    for t = 1:T
        % Propagate SV states
        sig_S = (1-rho_sigS)*sigSbar + rho_sigS*sig_S + eta_S*randn(N,1);
        sig_T = (1-rho_sigT)*sigTbar + rho_sigT*sig_T + eta_T*randn(N,1);
        % Propagate tau_s (random)
        eps_S = randn(N,1);
        tau_s = rho_S*tau_s + exp(sig_S) .* eps_S;
        % IMPLY tau_m from the observation constraint tau_M = tau_s + tau_m
        tau_m  = y(t,1) - tau_s;
        % Innovation in tau_m given its AR(1) dynamics with vol exp(sig_T)
        u_m    = tau_m - rho_M*tau_m_prev;
        log_w  = -0.5*log_2pi - sig_T - 0.5*(u_m.^2) ./ exp(2*sig_T);

        m = max(log_w);
        if ~isfinite(m)
            logL = -Inf;
            if store_level >= 1; filt = struct('x_med',NaN(T,3),'x_p025',NaN(T,3),'x_p975',NaN(T,3),'ESS',NaN(T,1)); else; filt = struct('ESS',NaN(T,1)); end
            return
        end
        w  = exp(log_w - m);
        sw = sum(w);
        if sw <= 0 || ~isfinite(sw)
            logL = -Inf;
            if store_level >= 1; filt = struct('x_med',NaN(T,3),'x_p025',NaN(T,3),'x_p975',NaN(T,3),'ESS',NaN(T,1)); else; filt = struct('ESS',NaN(T,1)); end
            return
        end
        logL = logL + m + log(sw) - log(N);

        wn     = w / sw;
        ESS(t) = 1 / sum(wn.^2);

        % Systematic resampling
        idx        = sys_resample(wn);
        tau_s      = tau_s(idx);
        sig_S      = sig_S(idx);
        sig_T      = sig_T(idx);
        tau_m_prev = tau_m(idx);

        if store_level >= 1
            x_med(t,1)  = median(tau_s);
            x_med(t,2)  = median(sig_S);
            x_med(t,3)  = median(sig_T);
            x_p025(t,1) = quantile(tau_s, 0.025);
            x_p025(t,2) = quantile(sig_S, 0.025);
            x_p025(t,3) = quantile(sig_T, 0.025);
            x_p975(t,1) = quantile(tau_s, 0.95);
            x_p975(t,2) = quantile(sig_S, 0.95);
            x_p975(t,3) = quantile(sig_T, 0.95);
        end
    end

    if store_level >= 1
        filt = struct('x_med', x_med, 'x_p025', x_p025, 'x_p975', x_p975, 'ESS', ESS);
    else
        filt = struct('ESS', ESS);
    end
end


function idx = sys_resample(w)
    N  = numel(w);
    u  = (rand + (0:N-1)') / N;
    cw = cumsum(w); cw(end) = 1;
    idx = zeros(N,1); j = 1;
    for i = 1:N
        while u(i) > cw(j)
            j = j + 1;
            if j > N; j = N; break; end
        end
        idx(i) = j;
    end
end
