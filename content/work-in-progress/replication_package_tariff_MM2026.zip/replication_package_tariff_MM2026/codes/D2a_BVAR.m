%  Identification — baseline BVAR


clearvars -except startYear anchorSet plot_fname
clc

%% ── Paths ──
codeDir = fileparts(mfilename('fullpath'));
rootDir = fileparts(codeDir);
addpath(genpath(fullfile(codeDir, 'functions')));

%% ── Data ─────────────────────────────────────────────────────────────────
datafile    = fullfile(rootDir, 'dataset', 'TariffData_CA_neer.mat');
panelselect = 1:10;

if ~exist('startYear','var'); startYear = 2002; end
if ~exist('anchorSet','var'); anchorSet = 'baseline'; end
if startYear == 1990; sampleTag = 'long'; else; sampleTag = 'short'; end
startQuarter = 1;
endYear      = 2025;
endQuarter   = 2;

%% ── Model specification ──────────────────────────────────────────────────

constant = 1;           % include constant
exog     = [];          % no additional exogenous variables
p        = 4;           % lag order (quarterly)
h        = 0;           % forecast horizon

%% ── Reduced-form prior ───────────────────────────────────────────────────

prior_settings.prior_family = 'conjugate';
prior_settings.prior        = 'flat';


%% ── Structural identification ──

StructuralIdentification = 'Signs/Zeros';
agnostic                 = 'irfs';

SR  = {};
ZR  = {};
NSR = {};
EBR = {}; 

%% ── Dominance identification settings ───────────────────────────────────
%
%  Variable order in TariffData_CA_neer.mat:
%    1:log_invest         2:log_exp        3:log_imp        4:trade_balance_ngdp
%    5:log_gdp            6:cpi            7:macro_unc100   8:log_neer
%    9:weighted_tau      10:fed_funds

h_dominance = 1;     % HD horizon
tau_idx     = 9;     % column index of weighted_tau
neer_idx    = 8;     % column index of log_neer


if strcmp(anchorSet, 'extended')
    anchor_dates = [datenum(2018, 10, 1);
                    datenum(2019,  7, 1);
                    datenum(2019, 10, 1);
                    datenum(2025,  4, 1)];
else
    anchor_dates = [datenum(2018, 10, 1);
                    datenum(2025,  4, 1)];
end

anchor_signs = ones(numel(anchor_dates), 1);


%% ── Imports sign restriction ─────────────────────────────────────────────

imp_idx        = 3;              % column index of log_imp
imp_sign_restr = -1;             % imports go opposite to the tariff shock direction (= -(+1))
h_imp          = 2;              % apply restriction at h = 1, 2 (not h = 0)

%% ── Sign restriction on the tariff-shock impact loading ─────────────

n_bvar           = numel(panelselect);
b_sign           = zeros(n_bvar,1);   % 0 = free, +1 / -1 = restricted
b_sign(tau_idx)  = +1;                % tariff shock raises tariffs on impact
b_sign(neer_idx) =  0;                % set to +1 to also require NEER appreciation at h = 0
% b_sign(imp_idx) = -1;               % only if imports are to be restricted at h = 0 too
b_tol            = 0;

%% ── Sampler settings ─────────────────────────────────────────────────────

numDesiredDraws  = 1000;
BetaSigmaTries   = 100;
Qs_per_BetaSigma = 100;
nRepsWeights     = 1000;

cumulateWhich = [];

%% ── Run ──────────────────────────────────────────────────────────────────

rng('default')
Run_SVAR_tariff_SignImports_signrestriction

%% ── Post-processing ──────────────────────────────────────────────────────

hmax_plot = 15;   % report horizons 0-20 quarters

n_vars = size(Draws_IRFs, 1);
IRF_median = median(Draws_IRFs(:,1,1:hmax_plot+1,:), 4);
IRF_q16    = quantile(Draws_IRFs(:,1,1:hmax_plot+1,:), 0.16, 4);
IRF_q84    = quantile(Draws_IRFs(:,1,1:hmax_plot+1,:), 0.84, 4);
IRF_q05    = quantile(Draws_IRFs(:,1,1:hmax_plot+1,:), 0.05, 4);
IRF_q95    = quantile(Draws_IRFs(:,1,1:hmax_plot+1,:), 0.95, 4);

fprintf('\nDone. %d admissible draws saved.\n', numSavedDraws);

%% ── Plot IRFs ────────────────────────────────────────────────────────────────

if strcmp(anchorSet, 'extended')
    plot_fname = sprintf('IRFs_Tariff_NEER_from%d_extended_signrestriction.png', startYear);
else
    plot_fname = sprintf('IRFs_Tariff_NEER_from%d_signrestriction.png', startYear);
end
Plot_IRFs_Tariff_CA

%% ── Output directories ─────────────────────────────────────────────────────

shockDir  = fullfile(rootDir, 'output', 'extracted_shocks');

if ~exist(shockDir, 'dir')
    mkdir(shockDir);
end

shockFile = fullfile(shockDir, sprintf('shocks_SignImports_signrestriction_%s_%s.xlsx', anchorSet, sampleTag));
shockMat  = fullfile(shockDir, sprintf('structural_shocks_SignImports_signrestriction_%s_%s.mat', anchorSet, sampleTag));

%% ── Save full identification output ────────────────────────────────────────

if ~exist('lags', 'var')
    lags = p;
end

save(fullfile(shockDir, sprintf('full_identification_output_SignImports_signrestriction_%s_%s.mat', anchorSet, sampleTag)), ...
    'Draws_Shocks', 'Draws_IRFs', 'dates', 'varNames', ...
    'p', 'lags', 'numSavedDraws', ...
    'b_sign', 'b_tol', '-v7.3');   % b_sign/b_tol recorded for provenance

%% ── Export historical structural shocks for plotted tariff shock ───────────

fprintf('Exporting historical structural shocks for plotted tariff shock...\n');

% -------------------------------------------------------------------------
% 1. Identify response variable: weighted_tau
% -------------------------------------------------------------------------

tau_idx = find(strcmpi(varNames, 'weighted_tau'));

if isempty(tau_idx)
    error('Variable "weighted_tau" not found in varNames.');
end

% -------------------------------------------------------------------------
% 2. Identify structural shock column
% -------------------------------------------------------------------------

shock_idx = 1;

% -------------------------------------------------------------------------
% 3. Compute same 1pp-impact normalization used in the plotted IRF
% -------------------------------------------------------------------------

impact_draws_save = squeeze(Draws_IRFs(tau_idx, shock_idx, 1, :));
impact_med_save   = median(impact_draws_save);

if ~isfinite(impact_med_save) || abs(impact_med_save) < 1e-12
    warning('Tariff impact is zero/invalid — no 1pp normalization applied.');
    scale_save = 1;
else
    scale_save = 1 / impact_med_save;
end


% -------------------------------------------------------------------------
% 4. Stack historical structural shocks across posterior draws
% -------------------------------------------------------------------------

Nd_save = size(Draws_Shocks, 3);
T_save  = size(Draws_Shocks, 1);

tau_shocks_raw_all = squeeze(Draws_Shocks(:, shock_idx, :))';   % Nd x T

tau_shocks_1pp_all = tau_shocks_raw_all / scale_save;

% -------------------------------------------------------------------------
% 5. Posterior summaries
% -------------------------------------------------------------------------

tau_raw_median = median(tau_shocks_raw_all, 1)';
tau_raw_mean   = mean(tau_shocks_raw_all, 1)';
tau_raw_p16    = prctile(tau_shocks_raw_all, 16, 1)';
tau_raw_p84    = prctile(tau_shocks_raw_all, 84, 1)';
tau_raw_p05    = prctile(tau_shocks_raw_all,  5, 1)';
tau_raw_p95    = prctile(tau_shocks_raw_all, 95, 1)';

tau_1pp_median = median(tau_shocks_1pp_all, 1)';
tau_1pp_mean   = mean(tau_shocks_1pp_all, 1)';
tau_1pp_p16    = prctile(tau_shocks_1pp_all, 16, 1)';
tau_1pp_p84    = prctile(tau_shocks_1pp_all, 84, 1)';
tau_1pp_p05    = prctile(tau_shocks_1pp_all,  5, 1)';
tau_1pp_p95    = prctile(tau_shocks_1pp_all, 95, 1)';

% -------------------------------------------------------------------------
% 6. Build quarterly Date variable for the estimation sample
% -------------------------------------------------------------------------


if exist('lags', 'var')
    p_save = lags;
elseif exist('p', 'var')
    p_save = p;
else
    error('Neither "lags" nor "p" exists. Cannot align shock dates.');
end



if exist('dates', 'var') && numel(dates) >= p_save + T_save
    shock_dn = dates(p_save+1 : p_save+T_save);
    if isdatetime(shock_dn)
        shock_years    = year(shock_dn);
        shock_quarters = quarter(shock_dn);
    else
        shock_dn       = shock_dn(:);
        shock_years    = year(datetime(shock_dn, 'ConvertFrom','datenum'));
        shock_quarters = ceil(month(datetime(shock_dn, 'ConvertFrom','datenum')) / 3);
    end
elseif exist('sample_dates', 'var') && numel(sample_dates) >= p_save + T_save
    shock_dn = sample_dates(p_save+1 : p_save+T_save);
    shock_dn = shock_dn(:);
    shock_years    = year(datetime(shock_dn, 'ConvertFrom','datenum'));
    shock_quarters = ceil(month(datetime(shock_dn, 'ConvertFrom','datenum')) / 3);
else
    raw_years    = [];
    raw_quarters = [];
    yy = startYear;
    qq = startQuarter;
    while (yy < endYear) || (yy == endYear && qq <= endQuarter)
        raw_years    = [raw_years; yy];
        raw_quarters = [raw_quarters; qq];
        qq = qq + 1;
        if qq == 5
            qq = 1;
            yy = yy + 1;
        end
    end
    if length(raw_years) < p_save + T_save
        error('Date vector is too short: check start/end dates or lag alignment.');
    end
    shock_years    = raw_years(p_save+1 : p_save+T_save);
    shock_quarters = raw_quarters(p_save+1 : p_save+T_save);
end

Date = cell(T_save, 1);
for t = 1:T_save
    Date{t} = sprintf('%dQ%d', shock_years(t), shock_quarters(t));
end

% -------------------------------------------------------------------------
% 7. Export structural shocks 
% -------------------------------------------------------------------------

T_export = table( ...
    Date, ...
    tau_1pp_median, tau_1pp_mean, ...
    tau_1pp_p16, tau_1pp_p84, ...
    tau_1pp_p05, tau_1pp_p95, ...
    'VariableNames', { ...
        'Date', 'Median', 'Mean', ...
        'P16', 'P84', 'P05', 'P95' ...
    } ...
);

writetable(T_export, shockFile, 'Sheet', 'Summary');

% -------------------------------------------------------------------------
% 8. Diagnostic sheet with raw structural shocks
% -------------------------------------------------------------------------
T_raw_export = table( ...
    Date, ...
    tau_raw_median, tau_raw_mean, ...
    tau_raw_p16, tau_raw_p84, ...
    tau_raw_p05, tau_raw_p95, ...
    'VariableNames', { ...
        'Date', 'Median', 'Mean', ...
        'P16', 'P84', 'P05', 'P95' ...
    } ...
);

writetable(T_raw_export, shockFile, 'Sheet', 'Summary_raw');

% -------------------------------------------------------------------------
% 9. Save MATLAB file
% -------------------------------------------------------------------------

save(shockMat, ...
    'tau_shocks_raw_all', ...
    'tau_shocks_1pp_all', ...
    'tau_raw_median', 'tau_raw_mean', ...
    'tau_raw_p16', 'tau_raw_p84', 'tau_raw_p05', 'tau_raw_p95', ...
    'tau_1pp_median', 'tau_1pp_mean', ...
    'tau_1pp_p16', 'tau_1pp_p84', 'tau_1pp_p05', 'tau_1pp_p95', ...
    'Date', 'shock_years', 'shock_quarters', ...
    'scale_save', 'impact_med_save', ...
    'shock_idx', 'tau_idx');

fprintf('  Saved Excel file:  %s\n', shockFile);
fprintf('  Saved MATLAB file: %s\n', shockMat);