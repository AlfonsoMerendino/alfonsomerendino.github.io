%% Historical decomposition
%
%  Historical decomposition of REER into all structural-shock contributions.

clear; clc;

%% ── PATHS ──

codeDir  = fileparts(mfilename('fullpath'));
funpath  = fullfile(codeDir, 'functions');
datafile = fullfile(codeDir, '..', 'dataset', 'TariffData_CA_reer.mat');
outdir   = fullfile(codeDir, '..', 'output', 'output_hd_reer');

addpath(funpath);

%% ── SETTINGS ──
%  Identical 10-var spec, prior, lags and identification (baseline anchors +
%  imports sign restriction)

panelselect  = 1:10;

startYear    = 1990;
startQuarter = 1;
endYear      = 2025;
endQuarter   = 4;

%% Model

constant = 1;
exog     = [];
p        = 4;
h        = 0;

%% Prior

prior_settings.prior_family = 'conjugate';
prior_settings.prior        = 'flat';

%% Structural identification

StructuralIdentification = 'Signs/Zeros';
agnostic                 = 'irfs';

SR  = {};
ZR  = {};
NSR = {};
EBR = {};

%% Dominance

h_dominance = 1;
tau_idx     = 9;    % column index of weighted_tau
reer_idx    = 8;    % column index of log_reer
neer_idx    = reer_idx;   % CheckHDDominance's neer_idx arg (its NEER-HD check is
                          % commented out inside that function, so the value is
                          % unused — this only needs to exist as a variable)

%{
anchor_dates = [datenum(2018, 10, 1);
                datenum(2019, 7, 1);
                datenum(2019, 10, 1);
                datenum(2025, 4, 1)];
%}

% Baseline anchors
anchor_dates = [datenum(2018, 10, 1);
                datenum(2025, 4, 1)];


%anchor_signs = [+1; +1; +1; +1];
anchor_signs = [+1; +1];


%% Imports sign restriction

imp_idx        = 3;
imp_sign_restr = -1;
h_imp          = 2;

n_bvar           = numel(panelselect);
b_sign           = zeros(n_bvar,1);
b_sign(tau_idx)  = +1;
b_tol            = 0;

%% Sampler

numDesiredDraws  = 1000;
BetaSigmaTries   = 100;
Qs_per_BetaSigma = 100;
nRepsWeights     = 1000;

cumulateWhich = [];

%% ── OUTPUT DIRECTORY ─────────────────────────────────────────────────────

if ~exist(outdir, 'dir'); mkdir(outdir); end

%% ── ESTIMATION ──

rerun_estimation = true;    % <- set to false to reuse the cache after one run

cachefile = fullfile(outdir, 'estimation_cache_SignImports_reer.mat');

if ~rerun_estimation && exist(cachefile, 'file')

    fprintf('Loading cached estimation output ...\n  %s\n', cachefile);
    load(cachefile, ...
        'Beta_save', 'A0_save', 'Sigma_save', ...
        'y', 'exog', 'dates', 'varNames', 'n', 'T', 'p', 'constant', ...
        'numSavedDraws');
    fprintf('  Loaded %d draws.\n', numSavedDraws);

else

    fprintf('Running estimation (Run_SVAR_tariff_SignImports_signrestriction) ...\n');
    rng('default');
    Run_SVAR_tariff_SignImports_signrestriction

    Nd_actual  = numSavedDraws;
    Beta_save  = Beta_save(:,:,  1:Nd_actual);
    A0_save    = A0_save(:,:,    1:Nd_actual);
    Sigma_save = Sigma_save(:,:, 1:Nd_actual);

    save(cachefile, ...
        'Beta_save', 'A0_save', 'Sigma_save', ...
        'y', 'exog', 'dates', 'varNames', 'n', 'T', 'p', 'constant', ...
        'numSavedDraws', '-v7.3');
    fprintf('Cached to:\n  %s\n', cachefile);

end

%% ── VARIABLE INDICES ─────────────────────────────────────────────────────

reer_col         = reer_idx;       % = 8
tariff_shock_col = 1;              % tariff shock always in column 1 of A0_save

%% ── COMPUTE HISTORICAL DECOMPOSITION OF REER ────────────────────────────

Nd   = numSavedDraws;
T_hd = T - p + 1;

fprintf('Computing HD of REER (%d draws, %d time steps) ...\n', Nd, T_hd);

HD_reer_all = nan(T_hd, n, Nd);

nexog       = size(exog, 2);
Beta_c_s    = Beta_save(1:nexog,     :, :);
Beta_lags_s = Beta_save(nexog+1:end, :, :);

y_par    = y;
exog_par = exog;
p_par    = p;
reer_c   = reer_col;

parfor draw = 1:Nd
    A0_d    = A0_save(:,:, draw);
    delta_d = Beta_c_s(:,:, draw)';
    phi_d   = Beta_lags_s(:,:, draw)';
    [~, ~, ~, ~, HDshock] = Get_SVAR_results( ...
        y_par, exog_par, A0_d, delta_d, phi_d, p_par, 0);
    HD_reer_all(:, :, draw) = squeeze(HDshock(reer_c, :, :));
end

fprintf('Done.\n');

%% ── POSTERIOR MEDIANS ────────────────────────────────────────────────────

HD_reer_med = median(HD_reer_all, 3);

HD_total_med = median(squeeze(sum(HD_reer_all, 2)), 2);   % T_hd x 1

plot_dates = dates(p : end);

%% ── SAVE RESULTS ─────────────────────────────────────────────────────────

hdfile = fullfile(outdir, 'HD_reer_results.mat');
save(hdfile, ...
    'HD_reer_all', 'HD_reer_med', 'HD_total_med', ...
    'plot_dates', 'varNames', 'n', 'p', 'Nd', 'reer_col', 'tariff_shock_col', ...
    '-v7.3');
fprintf('Saved HD results to:\n  %s\n', hdfile);
