*===============================================================================
* Merge the S-TPU series into the analysis dataset.
*===============================================================================

clear all
set more off

if "$dir" == "" global dir = cond(substr("`c(pwd)'",-5,5)=="codes", substr("`c(pwd)'",1,length("`c(pwd)'")-6), "`c(pwd)'")
global dataset "$dir/dataset"
cd "$dir"

capture confirm file "$dataset/output_stpu_sv_FULLCALIB/STPU_SV_FULLCALIB_STPU_index.xlsx"
if _rc {
    di as error "S-TPU files not found in $dataset/output_stpu_sv_FULLCALIB/."
    di as error "Run A0_STPU_stochastic_volatility.m first, then re-run A1b."
    exit 601
}

*--------------------------------------------------------*
* S-TPU index: structural and total filtered variance
*--------------------------------------------------------*
import excel using "$dataset/output_stpu_sv_FULLCALIB/STPU_SV_FULLCALIB_STPU_index.xlsx", ///
    firstrow case(lower) clear
gen struct_tpu_sv_fullcalib = stpu
gen tot_var_sv_fullcalib    = total_var
gen date = quarterly(date_str, "YQ")
format date %tq
keep date struct_tpu_sv_fullcalib tot_var_sv_fullcalib
merge 1:1 date using "$dataset/data.dta", nogen
save "$dataset/data.dta", replace

*--------------------------------------------------------*
* S-TPU series: filtered structural tariff (tau_s)
*--------------------------------------------------------*
import excel using "$dataset/output_stpu_sv_FULLCALIB/STPU_SV_FULLCALIB_series.xlsx", ///
    firstrow case(lower) clear
gen tau_s_fullcalib = tau_s_filt
cap drop date
gen date = quarterly(date_str, "YQ")
format date %tq
keep date tau_s_fullcalib
merge 1:1 date using "$dataset/data.dta", nogen
save "$dataset/data.dta", replace


capture drop date_str
gen str10 date_str = string(date, "%tq")
order date_str, first
save "$dataset/data.dta", replace
export excel "$dataset/data.xlsx", firstrow(variables) replace
