%% State-dependent Local Projections on narrative-identified tariff shock

clear all; close all; clc
rng default

set(groot, 'defaultAxesTickLabelInterpreter', 'latex');
set(groot, 'defaulttextinterpreter',          'latex');
set(groot, 'defaultLegendInterpreter',        'latex');

%% -- USER SETTINGS --------------------------------------------------------
codeDir       = fileparts(mfilename('fullpath'));
datafile_xlsx = fullfile(codeDir, '..', 'dataset', 'data.xlsx');
figDir        = fullfile(codeDir, '..', 'output', 'output_LP');

addpath(fullfile(codeDir, 'functions'));


sample_list = {
    struct('tag', 'short', ...
           'startdate', '1990q1', 'enddate', '2025q2', ...
           'startYear', 1990, 'startQuarter', 1, ...
           'endYear',   2025, 'endQuarter',   2)
};

% --- Baseline anchor list ------------------------------------------------
standard_dates = [];
standard_dates(end+1,1) = datenum(2018, 10, 1);
standard_dates(end+1,1) = datenum(2025,  4, 1);
standard_signs = [+1; +1];

% --- Extended anchor list ------------------------------------------------
extended_dates = [];
extended_dates(end+1,1) = datenum(2018, 10, 1);
extended_dates(end+1,1) = datenum(2019,  7, 1);
extended_dates(end+1,1) = datenum(2019, 10, 1);
extended_dates(end+1,1) = datenum(2025,  4, 1);
extended_signs = [+1; +1; +1; +1];


anchor_list = {
    struct('tag', 'extended', 'dates', extended_dates, 'signs', extended_signs)
};

state_var  = 'struct_tpu_sv_fullcalib';

percentile_list = [70 60 80 90];

% LP settings
pLP       = 4;
horizon   = 6;
alpha     = 0.10;      % 90% bands
alpha2    = 0.32;      % 68% bands
shockSize = 1;

nwLagExtra = 0;
nInnerSim   = 100;

% LP response variables (6 panels, 2x3 layout):
%   Row 1 (external block):   Trade balance / GDP, NEER, REER
%   Row 2 (real / monetary):  Real GDP, CPI inflation, Fed Funds Rate
response_vars  = {'trade_balance_ngdp', 'log_neer', 'log_reer', ...
                  'log_gdp', 'cpi', 'fed_funds'};
subplot_labels = {'Trade balance / GDP', 'NEER', 'REER', ...
                  'Real GDP', 'CPI inflation (y-o-y)', 'Fed Funds Rate'};
cumulate_vars  = {};
pp_vars        = {'trade_balance_ngdp', 'cpi', 'fed_funds'};
level_vars     = {};

saveFigs = true;

%% -- FIXED IDENTIFICATION SETTINGS --
constant = 1;
exog     = [];
p        = 4;
h        = 0;

prior_settings.prior_family = 'conjugate';
prior_settings.prior        = 'flat';

StructuralIdentification = 'Signs/Zeros';
agnostic                 = 'irfs';
SR  = {};   ZR  = {};   NSR = {};   EBR = {};

% Variable order:
%   log_invest(1) log_exp(2) log_imp(3) trade_balance_ngdp(4) log_gdp(5)
%   cpi(6) macro_unc100(7) log_neer(8) weighted_tau(9) fed_funds(10)
h_dominance = 1;
tau_idx     = 9;
neer_idx    = 8;
imp_idx     = 3;


imp_sign_restr = -1;
h_imp          = 2;

numDesiredDraws  = 5000;

% --- USE STORED BVAR SHOCKS (skip the slow rejection sampler) -----------
USE_STORED_SHOCKS = false;     % false: re-run the BVAR sampler here (self-contained,
                               % but slow). Set true only if you have pre-saved
                               % Draws_Shocks files in stored_shocks_dir.
stored_shocks_dir = fullfile(codeDir, '..', 'output', 'extracted_shocks');

stored_file_map = struct('extended', 'full_identification_output_SignImports_extended_long.mat', ...
                         'standard', 'full_identification_output_SignImports_baseline_long.mat');
BetaSigmaTries   = 500;
Qs_per_BetaSigma = 500;
nRepsWeights     = 1000;
cumulateWhich    = [];

panelselect = 1:10;

n_bvar           = numel(panelselect);
b_sign           = zeros(n_bvar,1);
b_sign(tau_idx)  = +1;
b_tol            = 0;


if ~exist(figDir, 'dir'); mkdir(figDir); end

%% Load full data file once
fprintf('Loading data from %s...\n', datafile_xlsx);
opts = detectImportOptions(datafile_xlsx);
raw  = readtable(datafile_xlsx, opts);

raw.trade_balance_noy   = raw.log_exp - raw.log_imp;
raw.trade_balance_ngdp   = 100 * (raw.exp_nominal - raw.imp_nominal) ./ raw.ngdp;

if ismember('date', raw.Properties.VariableNames)
    dates_raw = raw.date;
elseif ismember('date_str', raw.Properties.VariableNames)
    dates_raw = raw.date_str;
else
    dates_raw = raw{:,1};
end
if isdatetime(dates_raw)
    yy = year(dates_raw);
    qq = floor((month(dates_raw)-1)/3) + 1;
    mm = (qq-1)*3 + 1;
    date_nums = datenum(yy, mm, 1);
else
    if iscell(dates_raw);  dates_str = dates_raw;
    else;                  dates_str = cellstr(string(dates_raw));
    end
    date_nums = NaN(size(dates_str));
    for i = 1:numel(dates_str)
        ds = strtrim(dates_str{i});
        if isempty(ds); continue; end
        qmatch = regexp(ds, '^(\d{4})[qQ](\d)$', 'tokens');
        if ~isempty(qmatch)
            yr = str2double(qmatch{1}{1}); qt = str2double(qmatch{1}{2});
            date_nums(i) = datenum(yr, (qt-1)*3+1, 1);
        end
    end
end

%% -- DOUBLE LOOP: sample x anchor configuration --------------------------
for si = 1:numel(sample_list)
for ai = 1:numel(anchor_list)

    sset  = sample_list{si};
    aset  = anchor_list{ai};
    runid = sprintf('%s_%s', sset.tag, aset.tag);

    fprintf('\n============================================================\n');
    fprintf('  Run %d / %d:  sample=%s   anchors=%s\n', ...
            (si-1)*numel(anchor_list)+ai, ...
            numel(sample_list)*numel(anchor_list), ...
            sset.tag, aset.tag);
    fprintf('============================================================\n');

    %% Per-iteration sample + anchor settings
    startdate    = sset.startdate;
    enddate      = sset.enddate;
    startYear    = sset.startYear;   startQuarter = sset.startQuarter;
    endYear      = sset.endYear;     endQuarter   = sset.endQuarter;

    anchor_dates = aset.dates;
    anchor_signs = aset.signs;

    exog = [];
    clear Draws_Shocks Draws_IRFs numSavedDraws posteriors

    %% Subset sample
    qmatch_s = regexp(startdate, '^(\d{4})[qQ](\d)$', 'tokens');
    yr = str2double(qmatch_s{1}{1}); qt = str2double(qmatch_s{1}{2});
    start_num = datenum(yr, (qt-1)*3+1, 1);
    qmatch_e = regexp(enddate, '^(\d{4})[qQ](\d)$', 'tokens');
    yr = str2double(qmatch_e{1}{1}); qt = str2double(qmatch_e{1}{2});
    end_num   = datenum(yr, (qt-1)*3+1, 1);

    sample_mask  = ~isnan(date_nums) & (date_nums >= start_num) & (date_nums <= end_num);
    raw_sample   = raw(sample_mask, :);
    sample_dates = date_nums(sample_mask);
    fprintf('  Sample %s to %s: %d observations\n', startdate, enddate, sum(sample_mask));

    %% Build VAR data matrix
    varNames = {'log_invest', 'log_exp', 'log_imp', 'trade_balance_ngdp', ...
                'log_gdp', 'cpi', 'macro_unc100', 'log_neer', 'weighted_tau', ...
                'fed_funds'};

    data = zeros(height(raw_sample), numel(varNames));
    skip_run = false;
    for i = 1:numel(varNames)
        if ~ismember(varNames{i}, raw_sample.Properties.VariableNames)
            warning('  VAR variable "%s" not found - skipping run.', varNames{i});
            skip_run = true; break;
        end
        data(:, i) = raw_sample.(varNames{i});
    end
    if skip_run; continue; end

    [sample_dates, sort_idx] = sort(sample_dates);
    data        = data(sort_idx, :);
    raw_sample  = raw_sample(sort_idx, :);

    if any(~isfinite(data(:)))
        warning('  Non-finite values in VAR data matrix - skipping run.');
        continue;
    end

    dates    = sample_dates(:);
    tempDir  = tempname();  mkdir(tempDir);
    datafile = fullfile(tempDir, 'TariffData_LP_narrative.mat');
    save(datafile, 'data', 'dates', 'varNames');

    %% Stage 1 -- Run narrative identification (or load stored shocks)
    if USE_STORED_SHOCKS
        if ~isfield(stored_file_map, aset.tag)
            warning('  USE_STORED_SHOCKS=true but no stored file mapped for anchor "%s" - falling back to rerun.', aset.tag);
            Run_SVAR_tariff_SignImports_signrestriction
        else
            stored_path = fullfile(stored_shocks_dir, stored_file_map.(aset.tag));
            assert(isfile(stored_path), 'Stored shocks file not found: %s', stored_path);
            fprintf('  Stage 1: LOADING stored BVAR shocks from %s\n', stored_path);
            S_stored      = load(stored_path, 'Draws_Shocks', 'Draws_IRFs', 'numSavedDraws', 'dates');
            Draws_Shocks  = S_stored.Draws_Shocks;     % T_post_lag x n_vars x n_draws
            Draws_IRFs    = S_stored.Draws_IRFs;
            numSavedDraws = S_stored.numSavedDraws;

            stored_post_lag_dates = S_stored.dates((p+1):end);
            cur_end_num = datenum(sset.endYear, (sset.endQuarter-1)*3+1, 1);
            keep_t      = stored_post_lag_dates <= cur_end_num;
            n_keep_t    = sum(keep_t);
            n_stored    = size(Draws_Shocks, 1);
            if n_keep_t < n_stored
                fprintf('    Truncating stored shocks: %d -> %d post-lag quarters (drop trailing dates > %s).\n', ...
                        n_stored, n_keep_t, datestr(cur_end_num));
                Draws_Shocks = Draws_Shocks(keep_t, :, :);
            elseif n_keep_t > n_stored
                error('  Current sample ends after stored shocks (%s). Cannot extend.', datestr(stored_post_lag_dates(end)));
            end
        end
    else
        fprintf('  Stage 1: narrative + sign-restrictions identification...\n');
        fprintf('    (numDesiredDraws=%d; this may take several minutes.)\n', numDesiredDraws);
        Run_SVAR_tariff_SignImports_signrestriction
    end

    if ~exist('numSavedDraws','var') || numSavedDraws < 1
        warning('  No admissible draws produced - skipping LP for this run.');
        if exist(datafile,'file'); delete(datafile); end
        if exist(tempDir,'dir');   rmdir(tempDir,'s'); end
        continue;
    end
    fprintf('    Identification done: %d admissible draws.\n', numSavedDraws);

    %% Stage 2 -- Extract narrative-identified tariff shocks
    shock_idx = 1;

    impact_draws = squeeze(Draws_IRFs(tau_idx, shock_idx, 1, :));
    impact_med   = median(impact_draws);
    if ~isfinite(impact_med) || abs(impact_med) < 1e-12
        warning('  Tariff impact zero/invalid - no normalisation applied.');
        impact_norm = 1;
    else
        impact_norm = impact_med;
    end

    Nd_save        = size(Draws_Shocks, 3);
    tau_shocks_raw = squeeze(Draws_Shocks(:, shock_idx, :))';   % Nd x T
    tau_shocks_1pp = tau_shocks_raw * impact_norm;
    tau_median     = median(tau_shocks_1pp, 1)';                % T x 1
    T_shock        = numel(tau_median);

    %% Build LP dataset (post-lag rows align with shocks)
    lp_table = raw_sample(p+1:end, :);
    if size(lp_table, 1) ~= T_shock
        warning('  Row mismatch (lp_table=%d, shocks=%d) - skipping.', height(lp_table), T_shock);
        if exist(datafile,'file'); delete(datafile); end
        if exist(tempDir,'dir');   rmdir(tempDir,'s'); end
        continue;
    end

    if ~ismember(state_var, lp_table.Properties.VariableNames)
        error('State variable "%s" not found.', state_var);
    end

    state_vec = lp_table.(state_var);
    nan_mask  = isnan(state_vec);
    if any(nan_mask)
        first_valid = find(~nan_mask, 1, 'first');
        last_valid  = find(~nan_mask, 1, 'last');
        if any(nan_mask(first_valid:last_valid))
            warning('  State variable "%s" has interior NaNs - skipping LP.', state_var);
            if exist(datafile,'file'); delete(datafile); end
            if exist(tempDir,'dir');   rmdir(tempDir,'s'); end
            continue;
        end
        n_drop = sum(nan_mask);
        fprintf('    Trimming %d row(s) with NaN in state variable.\n', n_drop);
        keep              = first_valid:last_valid;
        lp_table          = lp_table(keep, :);
        tau_shocks_1pp    = tau_shocks_1pp(:, keep);
        tau_median        = tau_median(keep);
        T_shock           = numel(tau_median);
    end
    uncertainty = lp_table.(state_var);

    nResp    = numel(response_vars);
    respData = zeros(height(lp_table), nResp);
    skip_resp = false;
    for kk = 1:nResp
        rv = response_vars{kk};
        if ~ismember(rv, lp_table.Properties.VariableNames)
            warning('  Response variable "%s" not found - skipping run.', rv);
            skip_resp = true; break;
        end
        respData(:, kk) = lp_table.(rv);
    end
    if skip_resp
        if exist(datafile,'file'); delete(datafile); end
        if exist(tempDir,'dir');   rmdir(tempDir,'s'); end
        continue;
    end
    if any(~isfinite(respData(:)))
        warning('  NaN/Inf in LP response data - skipping run.');
        if exist(datafile,'file'); delete(datafile); end
        if exist(tempDir,'dir');   rmdir(tempDir,'s'); end
        continue;
    end

    if ~ismember('weighted_tau', lp_table.Properties.VariableNames)
        error('Variable "weighted_tau" not found.');
    end

    wt_idx       = nResp + 1;
    allData      = [respData, lp_table.weighted_tau];
    nvar         = nResp + 1;
    cumulate_idx = find(ismember(response_vars, cumulate_vars));
    horizonLP    = horizon;

    %% Point estimate LP (using posterior median shock)
    
    for percentile = percentile_list

    fprintf('  Stage 2: LP point estimate...\n');
    thr     = prctile(uncertainty, percentile);
    HighVar = double(uncertainty >= thr);

    [IRFs_LP1, IRFs_LP12] = lp_estimate_hac(tau_median, allData, HighVar, ...
                                            pLP, horizonLP, nvar, ...
                                            cumulate_idx, nwLagExtra);

    den = IRFs_LP1(1, wt_idx);
    if ~isfinite(den) || abs(den) < 1e-12
        warning('  Cannot normalise (impact response of weighted_tau invalid) - skipping.');
        if exist(datafile,'file'); delete(datafile); end
        if exist(tempDir,'dir');   rmdir(tempDir,'s'); end
        continue;
    end
    IRFs_LP1  = IRFs_LP1  ./ den * shockSize;
    IRFs_LP12 = IRFs_LP12 ./ den * shockSize;

    fprintf('impact_med=%.4f den=%.4f\n', impact_med, den);
    %% Total uncertainty = between-draw variance + average within-draw HAC
    fprintf('  HAC + law-of-total-variance over %d narrative draws (NW lag = h + %d for level)...\n', ...
            Nd_save, nwLagExtra);

    perdraw_IRF1  = zeros(horizonLP+1, nvar, Nd_save);
    perdraw_IRF12 = zeros(horizonLP+1, nvar, Nd_save);
    perdraw_V1    = zeros(horizonLP+1, nvar, Nd_save);
    perdraw_V12   = zeros(horizonLP+1, nvar, Nd_save);

    den_inv  = (1/den)   * shockSize;
    den2_inv = (1/den^2) * shockSize^2;

    for d = 1:Nd_save
        shock_d = tau_shocks_1pp(d, :)';
        [IRF1_d, IRF12_d, V1_d, V12_d] = ...
            lp_estimate_hac(shock_d, allData, HighVar, ...
                            pLP, horizonLP, nvar, cumulate_idx, nwLagExtra);

        perdraw_IRF1(:,:,d)  = IRF1_d  * den_inv;
        perdraw_IRF12(:,:,d) = IRF12_d * den_inv;
        perdraw_V1(:,:,d)    = V1_d    * den2_inv;
        perdraw_V12(:,:,d)   = V12_d   * den2_inv;

        if mod(d, 100) == 0
            fprintf('    draw %d / %d\n', d, Nd_save);
        end
    end

    betweenVar_LP1 = var(perdraw_IRF1, 0, 3, 'omitnan');
    withinVar_LP1  = mean(perdraw_V1,  3, 'omitnan');

    fprintf('    Between/within variance share at h=1, weighted_tau, low state: %.2f / %.2f\n', ...
            betweenVar_LP1(1, wt_idx) / max(betweenVar_LP1(1, wt_idx) + withinVar_LP1(1, wt_idx), eps), ...
            withinVar_LP1(1, wt_idx)  / max(betweenVar_LP1(1, wt_idx) + withinVar_LP1(1, wt_idx), eps));

    %% Confidence bands 
    time = (0:horizonLP)';
    pooled_IRF1  = mix_draws(perdraw_IRF1,  perdraw_V1,  nInnerSim);
    pooled_IRF12 = mix_draws(perdraw_IRF12, perdraw_V12, nInnerSim);
    [upper90_low,  lower90_low,  upper68_low,  lower68_low] = ...
        qbands(pooled_IRF1,  IRFs_LP1,  alpha, alpha2);
    [upper90_high, lower90_high, upper68_high, lower68_high] = ...
        qbands(pooled_IRF12, IRFs_LP12, alpha, alpha2);

    %% Plot -- 2x3 panel figure
    % FINAL: swap colors so RED is the HIGH-uncertainty state (top 30% when
    % percentile=70).
    colHigh = [0.85 0.325 0.098];   % RED  -> top 30% (high uncertainty)
    colLow  = [0.10 0.447 0.741];   % BLUE -> bottom 70% (low/moderate uncertainty)

    fig = figure('Visible','off', ...
                 'Position',[100 100 1500 750], ...
                 'PaperPositionMode','Auto', ...
                 'Color','w');

    for kk = 1:nResp
        ax = subplot(2, 3, kk);

        irf_low  = IRFs_LP1(:,  kk);
        irf_high = IRFs_LP12(:, kk);

        hf = fill([time; flipud(time)], ...
                  [upper90_low(:,kk); flipud(lower90_low(:,kk))], ...
                  colLow, 'EdgeColor','none'); set(hf,'FaceAlpha',0.15); hold on;
        hf = fill([time; flipud(time)], ...
                  [upper68_low(:,kk); flipud(lower68_low(:,kk))], ...
                  colLow, 'EdgeColor','none'); set(hf,'FaceAlpha',0.35);
        hf = fill([time; flipud(time)], ...
                  [upper90_high(:,kk); flipud(lower90_high(:,kk))], ...
                  colHigh, 'EdgeColor','none'); set(hf,'FaceAlpha',0.15);
        hf = fill([time; flipud(time)], ...
                  [upper68_high(:,kk); flipud(lower68_high(:,kk))], ...
                  colHigh, 'EdgeColor','none'); set(hf,'FaceAlpha',0.35);

        yline(0, '-', 'Color', [0.5 0.5 0.5], 'LineWidth', 0.8);

        plot(time, irf_low,  '--', 'Color', colLow,  'LineWidth', 2);
        plot(time, irf_high, '-',  'Color', colHigh, 'LineWidth', 2);

        set(ax, 'Box','off', 'TickDir','out', ...
                'XLim',[0, horizonLP], 'XTick', 0:1:horizonLP, ...
                'FontSize', 14, 'FontName', 'Times New Roman', 'LineWidth', 1.0);

        title(['\textbf{' subplot_labels{kk} '}'], ...
              'FontSize', 18, 'FontName', 'Times New Roman');
        xlabel('\textrm{Quarters}', 'FontSize', 14, 'FontName', 'Times New Roman');

        if ismember(response_vars{kk}, level_vars)
            ylabel('\textrm{USD bn}', 'FontSize', 14, 'FontName', 'Times New Roman');
        elseif ismember(response_vars{kk}, pp_vars)
            ylabel('\textrm{Percentage Points}', 'FontSize', 14, 'FontName', 'Times New Roman');
        else
            ylabel('\textrm{Percent (\%)}', 'FontSize', 14, 'FontName', 'Times New Roman');
        end
        hold off;
    end

    axList = findall(fig, 'Type', 'axes');
    for ii = 1:numel(axList)
        pos = axList(ii).Position;
        axList(ii).Position = [pos(1), pos(2)*0.88 + 0.05, pos(3), pos(4)*0.88];
    end

    %% Save figure
    if saveFigs
        switch state_var
            case 'struct_tpu_sv_fullcalib'; state_lab = 'STPU';
            case 'tpu';                     state_lab = 'TPU';
            otherwise;                      state_lab = state_var;
        end
        fig_name = sprintf('LP_%s_top%d_%s_%s', ...
                           state_lab, 100-percentile, startdate, aset.tag);
        outFile  = fullfile(figDir, [fig_name '.png']);
        exportgraphics(fig, outFile, 'Resolution', 300);
        fprintf('  Saved: %s\n', fig_name);
    end
    close(fig);

    end

    if exist(datafile, 'file'); delete(datafile); end
    if exist(tempDir,  'dir');  rmdir(tempDir, 's'); end

end   % anchor loop
end   % sample loop

fprintf('\n=== All runs done. Figures saved to %s ===\n', figDir);


%% =========================================================================
%  HELPER FUNCTIONS
%% =========================================================================

function [IRF1, IRF12, V1, V12] = lp_estimate_hac(shockSeries, allData, HighVar, ...
                                                  pLP, horizonLP, nvar, ...
                                                  cumulate_idx, nwLagExtra)
% State-dependent local projection with Newey-West HAC variances.
%
% Outputs (each (horizonLP+1) x nvar):
%   IRF1  : low-state response  = b(1)
%   IRF12 : high-state response = b(1) + b(2)
%   V1    : HAC variance of b(1)
%   V12   : HAC variance of b(1) + b(2)   ( = V(1,1)+V(2,2)+2*V(1,2) )


IRF1  = zeros(horizonLP+1, nvar);
IRF12 = zeros(horizonLP+1, nvar);
V1    = zeros(horizonLP+1, nvar);
V12   = zeros(horizonLP+1, nvar);

for hh = 0:horizonLP
    for ii = 1:nvar
        is_cum = ismember(ii, cumulate_idx);
        if is_cum
            Treg = size(allData, 1) - pLP - horizonLP;
            yi   = zeros(Treg, 1);
            for s = 0:hh
                yi = yi + allData(1+pLP+s : end-horizonLP+s, ii);
            end
        else
            yi   = allData(1+pLP+hh : end-horizonLP+hh, ii);
            Treg = length(yi);
        end

        LagBlock = zeros(Treg, pLP);
        for jj = 1:pLP
            LagBlock(:, jj) = allData(1+pLP-jj : end-horizonLP-jj, ii);
        end

        Z   = shockSeries(1+pLP : end-horizonLP);
        HV  = HighVar(1+pLP : end-horizonLP);
        HZ  = HV .* Z;
        % State level HV added as a control. Without it the interaction
        % coefficient b(2) absorbs the direct effect of HighVar on y, which
        % biases the high-state IRF. Ordering of (b(1), b(2)) is preserved so
        % V(1,1), V(2,2), V(1,2) still index Z and HZ.
        Xlp = [Z, HZ, HV, LagBlock, ones(Treg, 1)];

        b = Xlp \ yi;
        e = yi - Xlp * b;

        IRF1(hh+1,  ii) = b(1);
        IRF12(hh+1, ii) = b(1) + b(2);

        XtX = Xlp' * Xlp;
        if rcond(XtX) < 1e-12 || ~all(isfinite(b))
            V1(hh+1,  ii) = NaN;
            V12(hh+1, ii) = NaN;
            continue;
        end

        if is_cum
            L = 2*hh + nwLagExtra;
        else
            L = hh   + nwLagExtra;
        end
        V = hac_cov(Xlp, e, L);
        V1(hh+1,  ii) = V(1,1);
        V12(hh+1, ii) = V(1,1) + V(2,2) + 2*V(1,2);
    end
end
end


function V = hac_cov(X, e, L)
% Newey-West sandwich covariance of OLS coefficient vector.
%   X : T x k regressor matrix
%   e : T x 1 OLS residuals
%   L : Bartlett truncation lag (L = 0 -> White heteroskedasticity-robust).

[T, ~] = size(X);
XtX    = X' * X;
u      = X .* e;
S      = u' * u;
Lmax   = min(max(L, 0), T-1);
for l = 1:Lmax
    w     = 1 - l/(L+1);
    Gamma = u(l+1:T, :)' * u(1:T-l, :);
    S     = S + w * (Gamma + Gamma');
end
V = (XtX \ S) / XtX;
end


function [u90, l90, u68, l68] = qbands(A3, pointEst, alpha, alpha2)
% Hall-recentered empirical-quantile bands 
center = prctile(A3, 50, 3);
shift  = pointEst - center;
u90 = prctile(A3, 100*(1 - alpha/2),  3) + shift;
l90 = prctile(A3, 100*(alpha/2),      3) + shift;
u68 = prctile(A3, 100*(1 - alpha2/2), 3) + shift;
l68 = prctile(A3, 100*(alpha2/2),     3) + shift;
end


function pooled = mix_draws(perdraw_IRF, perdraw_V, nInnerSim)
[H, nvar, Nd] = size(perdraw_IRF);
sd     = sqrt(max(perdraw_V, 0));
pooled = zeros(H, nvar, Nd*nInnerSim);
for s = 1:nInnerSim
    idx = (s-1)*Nd + (1:Nd);
    pooled(:,:,idx) = perdraw_IRF + sd .* randn(H, nvar, Nd);
end
end
