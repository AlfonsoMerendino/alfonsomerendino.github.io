function A = wish(h,n)

A = chol(h)'*randn(size(h,1),n);
A = A*A';