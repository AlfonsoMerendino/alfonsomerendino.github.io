function y = randsample(n, k, replace, w)

if nargin >= 4 && ~isempty(w)
    c = cumsum(w(:)) / sum(w);
    [~, y] = max(rand(k, 1) <= c.', [], 2);
    y = y(:);
elseif nargin >= 3 && replace
    y = randi(n, k, 1);
else
    p = randperm(n);
    y = p(1:k).';
end
end
