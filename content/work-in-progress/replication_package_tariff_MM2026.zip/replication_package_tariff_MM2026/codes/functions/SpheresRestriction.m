function y = SpheresRestriction(x,Z_IRF,n)

y=zeros(n,1);
k=0;
for j=1:n
    xj=x(k+1:k+n-(j-1+size(Z_IRF{j},1)));
    k=k+n-(j-1+size(Z_IRF{j},1));
    y(j)=norm(xj) - 1.0;
end