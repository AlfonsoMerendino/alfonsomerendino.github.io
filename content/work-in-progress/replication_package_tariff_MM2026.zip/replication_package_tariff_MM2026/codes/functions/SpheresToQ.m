function q = SpheresToQ(x, Z_IRF, nvar)

Q=zeros(nvar,nvar);
k=0;
for j=1:nvar
    
    s=nvar-(j-1+size(Z_IRF{j},1));
    xj=x(k+1:k+s);
    k=k+s;
    
    N=[Q(:,1:j-1), Z_IRF{j}'];
    Q(:,j)=perp(N)*(xj/norm(xj));
end

q=reshape(Q,nvar*nvar,1);
