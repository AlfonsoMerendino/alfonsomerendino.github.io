function ve = LogVolumeElement(f,x,h)

Dfx=NumericalDerivative(f,x);
if nargin > 2
    Dhx=NumericalDerivative(h,x);
    N=Dfx*perp(Dhx');
    ve=0.5*LogAbsDet(N'*N);
else
    ve=0.5*LogAbsDet(Dfx'*Dfx);
end
