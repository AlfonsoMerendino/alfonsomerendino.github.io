labels = struct();

labels.log_invest.title = 'Real private investment';
labels.log_invest.unit  = 'Percent (\%)';

labels.log_exp.title = 'Real exports';
labels.log_exp.unit  = 'Percent (\%)';

labels.log_imp.title = 'Real imports';
labels.log_imp.unit  = 'Percent (\%)';

labels.trade_balance_ngdp.title = 'Trade balance / GDP';
labels.trade_balance_ngdp.unit  = 'Percentage points';

labels.log_gdp.title = 'Real GDP';
labels.log_gdp.unit  = 'Percent (\%)';

labels.cpi.title = 'CPI inflation (y-o-y)';
labels.cpi.unit  = 'Percentage points';

labels.macro_unc100.title = 'Macro uncertainty';
labels.macro_unc100.unit  = 'Percent (\%)';

labels.log_neer.title = 'NEER';
labels.log_neer.unit  = 'Percent (\%)';

labels.weighted_tau.title = 'Weighted import tariff';
labels.weighted_tau.unit  = 'Percentage points';

labels.fed_funds.title = 'Federal funds rate';
labels.fed_funds.unit  = 'Percentage points';

if ~exist('Draws_IRFs', 'var')
    error('Draws_IRFs is not defined.');
end

if ~exist('varNames', 'var')
    error('varNames is not defined.');
end

if ~exist('tau_idx', 'var')
    error('tau_idx is not defined.');
end

if ~exist('hmax_plot', 'var')
    error('hmax_plot is not defined.');
end

impact_draws = squeeze(Draws_IRFs(tau_idx, 1, 1, :));
impact_med   = median(impact_draws);

if ~isfinite(impact_med) || abs(impact_med) < 1e-12
    warning('Plot_IRFs_Tariff_CA: tariff impact is zero/invalid — no normalisation applied.');
    scale = 1;
else
    scale = 1 / impact_med;
end

shock_idx = tau_idx;

exp_idx = find(strcmpi(varNames, 'log_exp'));
imp_idx = find(strcmpi(varNames, 'log_imp'));

if isempty(exp_idx)
    warning('Variable log_exp not found in varNames.');
end

if isempty(imp_idx)
    warning('Variable log_imp not found in varNames.');
end

desired_order = {'log_gdp', ...
                 'cpi', ...
                 'log_invest', ...
                 'log_neer', ...
                 'trade_balance_ngdp', ...
                 '__exp_imp__', ...
                 'macro_unc100', ...
                 'fed_funds', ...
                 'weighted_tau'};

plot_order = {};

for vi = 1:numel(desired_order)

    entry = desired_order{vi};

    if strcmpi(entry, '__exp_imp__')

        if ~isempty(exp_idx) && ~isempty(imp_idx)
            plot_order{end+1} = [exp_idx, imp_idx];
        else
            warning('log_exp and/or log_imp not found in varNames. Skipping exports/imports panel.');
        end

    else

        idx_tmp = find(strcmpi(varNames, entry));

        if ~isempty(idx_tmp)
            plot_order{end+1} = idx_tmp;
        else
            warning('Variable "%s" not found in varNames. Skipping this panel.', entry);
        end

    end

end

set(groot, 'defaultAxesTickLabelInterpreter', 'latex');
set(groot, 'defaultTextInterpreter',          'latex');
set(groot, 'defaultLegendInterpreter',        'latex');
set(groot, 'defaultAxesFontName',             'Times New Roman');
set(groot, 'defaultTextFontName',             'Times New Roman');

fig = figure('Color', 'w', ...
             'Units', 'pixels', ...
             'Position', [100 100 900 800]);

tiledlayout(3, 3, ...
            'Padding', 'compact', ...
            'TileSpacing', 'compact');

horizons = (0:hmax_plot)';
xfill    = [horizons; flipud(horizons)];


for pp = 1:numel(plot_order)

    entry = plot_order{pp};
    ax    = nexttile;

    hold(ax, 'on');

    if numel(entry) == 1

        ii = entry;

        all_irfs = squeeze(Draws_IRFs(ii, 1, 1:hmax_plot+1, :)) * scale;

        med_raw = median(all_irfs, 2);
        lb90    = quantile(all_irfs, 0.05, 2);
        ub90    = quantile(all_irfs, 0.95, 2);
        lb68    = quantile(all_irfs, 0.16, 2);
        ub68    = quantile(all_irfs, 0.84, 2);

        fp90 = fill(ax, xfill, [lb90; flipud(ub90)], ...
                    [0.65 0.80 0.95], ...
                    'EdgeColor', 'none');
        fp90.FaceAlpha = 0.45;

        fp68 = fill(ax, xfill, [lb68; flipud(ub68)], ...
                    [0.40 0.60 0.85], ...
                    'EdgeColor', 'none');
        fp68.FaceAlpha = 0.55;

        plot(ax, horizons, med_raw, ...
             'Color', [0 0.4470 0.7410], ...
             'LineWidth', 2);

        yline(ax, 0, '-', ...
              'Color', [0.5 0.5 0.5], ...
              'LineWidth', 0.8);

        key = lower(varNames{ii});

        if isfield(labels, key)
            ttxt = labels.(key).title;
            ytxt = labels.(key).unit;
        else
            ttxt = varNames{ii};
            ytxt = '';
        end

        title(ax, ['\textbf{' ttxt '}'], ...
              'FontSize', 22, 'FontName', 'Times New Roman');
        xlabel(ax, '\textrm{Quarters}', ...
               'FontSize', 17, 'FontName', 'Times New Roman');

        if ~isempty(ytxt)
            ylabel(ax, ['\textrm{' ytxt '}'], ...
                   'FontSize', 17, 'FontName', 'Times New Roman');
        end


    else

        clrs90 = {[0.65 0.80 0.95], [0.98 0.75 0.60]};
        clrs68 = {[0.40 0.60 0.85], [0.90 0.50 0.30]};
        clrs   = {[0 0.4470 0.7410], [0.8500 0.3250 0.0980]};

        leg_handles = gobjects(numel(entry), 1);
        leg_labels  = cell(numel(entry), 1);

        for vi = 1:numel(entry)

            ii = entry(vi);

            all_irfs = squeeze(Draws_IRFs(ii, 1, 1:hmax_plot+1, :)) * scale;

            med_raw = median(all_irfs, 2);
            lb90    = quantile(all_irfs, 0.05, 2);
            ub90    = quantile(all_irfs, 0.95, 2);
            lb68    = quantile(all_irfs, 0.16, 2);
            ub68    = quantile(all_irfs, 0.84, 2);

            fp90 = fill(ax, xfill, [lb90; flipud(ub90)], ...
                        clrs90{vi}, ...
                        'EdgeColor', 'none');
            fp90.FaceAlpha = 0.45;

            fp68 = fill(ax, xfill, [lb68; flipud(ub68)], ...
                        clrs68{vi}, ...
                        'EdgeColor', 'none');
            fp68.FaceAlpha = 0.55;

            leg_handles(vi) = plot(ax, horizons, med_raw, ...
                                   'Color', clrs{vi}, ...
                                   'LineWidth', 2);

            key = lower(varNames{ii});

            if isfield(labels, key)
                leg_labels{vi} = labels.(key).title;
            else
                leg_labels{vi} = varNames{ii};
            end

        end

        yline(ax, 0, '-', ...
              'Color', [0.5 0.5 0.5], ...
              'LineWidth', 0.8);

        legend(ax, leg_handles, leg_labels, ...
               'Location', 'best', ...
               'Box', 'off', ...
               'FontSize', 14);

        title(ax, '\textbf{Real exports \& imports}', ...
              'FontSize', 22, 'FontName', 'Times New Roman');
        xlabel(ax, '\textrm{Quarters}', ...
               'FontSize', 17, 'FontName', 'Times New Roman');
        ylabel(ax, '\textrm{Percent (\%)}', ...
               'FontSize', 17, 'FontName', 'Times New Roman');

    end

    set(ax, 'Box', 'off', 'TickDir', 'out', ...
            'Layer', 'top', ...
            'XGrid', 'off', 'YGrid', 'off', ...
            'FontSize', 15, 'FontName', 'Times New Roman', ...
            'LineWidth', 1.0);

    xlim(ax, [0 hmax_plot]);

end


out_dir = fullfile(fileparts(mfilename('fullpath')), '..', '..', 'output');

if ~exist(out_dir, 'dir')
    mkdir(out_dir);
end

if ~exist('plot_fname', 'var')
    plot_fname = 'IRFs_Tariff_baseline_short.png';
end

fname = fullfile(out_dir, plot_fname);

exportgraphics(fig, fname, 'Resolution', 300);

fprintf('IRF plot saved to %s\n', fname);
