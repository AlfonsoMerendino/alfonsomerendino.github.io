function [A0tilde,Qdraw,uw] = SignAndZeroRestrictions(Bdraw,Sigmadraw,p,exog,hirfs,S,Z,agnostic)

n = size(Sigmadraw,1);
m = n*p+size(exog,2);

hh       = @(x)chol(x);
fh_inv   = @(x)ReducedFormToStructural(x,hh,n,m);
fh_S_restrictions      = @(y)StructuralRestrictions(y,S,m,p,hirfs);
g        = @(y)StructuralToIRF(y,n,p);
fh_g_inv = @(y)IRFToReducedForm(y,hh,n,m,p);
g_inv_Z_restrictions   = @(z)IRFRestrictions(z,Z,m,p,hirfs);

dim=0;
for i=1:n
    dim=dim+n-(i-1+size(Z{i},1));
end

Bdraw = [Bdraw(size(exog,2)+1:end,:); Bdraw(1:size(exog,2),:)];

    Q0 = eye(n);

    structpara   = fh_inv([reshape(Bdraw,m*n,1); reshape(Sigmadraw,n*n,1); reshape(Q0,n*n,1)]);
    FA0Aplus     = FA0Aplus_f2(structpara,m,n,p,hirfs);
    
    Z_FA0Aplus  = cell(n,1);
    for j=1:n
        Z_FA0Aplus{j} = Z{j}*FA0Aplus;
    end
    f = @(x)SpheresToQ(x,Z_FA0Aplus,n);
    
    q_tilde=randn(dim,1);
    
    k=0;
    for i=1:n
       s  = n-(i-1+size(Z{i},1));
       qi = q_tilde(k+1:k+s);
       q_tilde(k+1:k+s) = qi/norm(qi);
       k  = k+s;
    end
    
    Qdraw=Q0*reshape(f(q_tilde),n,n);
   
    x=[reshape(Bdraw,m*n,1); reshape(Sigmadraw,n*n,1); reshape(Qdraw,n*n,1)];
    structpara = fh_inv(x);
    signs=fh_S_restrictions(structpara);    
    
    if (sum(signs>0))~=size(signs,1) 
        Qdraw = nan*Qdraw;
        uw = 0;
        A0tilde = nan;
    else
        
        A0 = chol(Sigmadraw)\eye(n);
        A0tilde = A0*Qdraw;
        
        if ~isempty(Z{1,:})
        
        switch agnostic
            case 'structural'
                
                storevefh =  log(2)*n*(n+1)/2 + LogAbsDet(Sigmadraw)*(m+2*n +1)/2;
                
                f_restrictions=@(x)SpheresRestriction(x,Z_FA0Aplus,n);
                storevegBS = LogVolumeElement(f,q_tilde,f_restrictions);

                storevefhZ = LogVolumeElement(fh,structpara,fh_Z_restrictions);

                uw = exp(storevefh + storevegBS - storevefhZ);
                
                
            case 'irfs'

                storevephi =  log(2)*n*(n+1)/2 - LogAbsDet(Sigmadraw)*(2*n*p-m-1)/2;
                
                f_restrictions=@(x)SpheresRestriction(x,Z_FA0Aplus,n);
                storevegBS = LogVolumeElement(f,q_tilde,f_restrictions);

                irfpara = g(structpara);
                storevephiZ = LogVolumeElement(fh_g_inv,irfpara,g_inv_Z_restrictions);

                uw = exp( storevephi + storevegBS - storevephiZ);
        end    
        
        else
            
            uw = 1;
        end
        
    end
    
end

