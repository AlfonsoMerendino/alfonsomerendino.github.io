function Df = NumericalDerivative(f, x, epsilon)

n=numel(x);
if nargin < 3
    epsilon=1.0e-6;
end
z=x;
for j=1:n
    z(j)=x(j)+epsilon;
    y1=f(z);
    z(j)=x(j)-epsilon;
    y0=f(z);
    z(j)=x(j);
    if j == 1
        Df=zeros(numel(y0),n);
    end
    Df(:,j)=(y1-y0)/(2*epsilon);
end