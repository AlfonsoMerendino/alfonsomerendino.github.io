function IRF = IRF_horizons(x, nvar, nlag, npredetermined, horizons)

if numel(horizons) == 0
    IRF = zeros(0,nvar);
else
    
    maxh=max(horizons(horizons ~= inf));
    long_run = (max(horizons) == inf);
    if maxh < nlag
        if long_run
            maxh=nlag;
        end
        q=maxh;
    else
        q=nlag;
    end
    
    n2=nvar*nvar;
    A=cell(nlag,1);
    A0=reshape(x(1:n2),nvar,nvar);
    Aplus=reshape(x(n2+1:n2+nvar*npredetermined),npredetermined,nvar);
    
    R=cell(maxh,1);
    
    for i=1:q
        A{i}=Aplus((i-1)*nvar+1:i*nvar,:);
        X = A0\A{i};
        for j=1:i-1
            X = X + R{j}*A{i-j};
        end
        R{i}=X/A0;
    end
    
    for i=nlag+1:maxh
        if nlag > 0
            X = R{i-nlag}*A{nlag};
        else
            X = zeros(nvar,nvar);
        end
        for j=1:nlag-1
            X = X + R{i-j}*A{j};
        end
        R{i}=X/A0;
    end
    
    if long_run
        R_long_run=A0;
        for j=1:nlag
            R_long_run=R_long_run - A{j};
        end
        R_long_run=inv(R_long_run);
    end
    
    IRF=zeros(numel(horizons)*nvar,nvar);
    for i=1:numel(horizons)
        if horizons(i) == inf
            IRF((i-1)*nvar+1:i*nvar,:)=R_long_run';
        elseif horizons(i) == 0
            IRF((i-1)*nvar+1:i*nvar,:)=inv(A0)';
        else
            IRF((i-1)*nvar+1:i*nvar,:)=R{horizons(i)}';
        end
    end
    
end




