function X_perp = perp(X)


[n,m]=size(X);
if n < m
    error('perp(X): number of rows must be greater than or equal to number of columns');
else
    Z=cell(m,1);
    for j=1:m
        z=X(j:end,j);
        nn=norm(z);
        z(1)=z(1)-nn;
        nn=sqrt(abs(2.0*nn*z(1)));
        if nn == 0    
        else
            z=(1.0/nn)*z;
            for k=j+1:m
                x=X(j:end,k);
                X(j:end,k)=x-(2*dot(z,x))*z;
            end
            Z{j}=z;
        end
    end
    
    I=eye(n);
    X_perp=I(:,m+1:end);
    for j=m:-1:1
        if ~isempty(Z{j})
            for k=1:n-m
                x=X_perp(j:end,k);
                X_perp(j:end,k)=x-(2*dot(Z{j},x))*Z{j};
            end
        end
    end
end