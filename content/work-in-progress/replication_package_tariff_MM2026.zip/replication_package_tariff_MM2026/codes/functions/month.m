function m =month(DateNumber)

tmp=datevec(DateNumber);
m=tmp(:,2);

end
