function y = IRFToReducedForm(x,h,n,m,p)

n2=n*n;
k=numel(x)/n - n*(p+1);
L=cell(p,1);

L0=reshape(x(1:n2),n,n)';
A=cell(p,1);

for i=1:p
    L{i}=reshape(x(i*n2+1:(i+1)*n2),n,n)';
    X = L{i}/L0;
    for j=1:i-1
        X = X - L{i-j}*A{j};
    end
    A{i}=L0\X;
end

Aplus=zeros(n*p+k,n);
for i=1:p
    Aplus((i-1)*n+1:i*n,:)=A{i};
end
Aplus(n*p+1:end,:)=reshape(x(n2*(p+1)+1:end),k,n);
A0=inv(L0);



B=Aplus/A0;
Sigma=inv(A0*A0');
Q=h(Sigma)*A0;

y=[reshape(B,m*n,1); reshape(Sigma,n*n,1); reshape(Q,n*n,1)];


