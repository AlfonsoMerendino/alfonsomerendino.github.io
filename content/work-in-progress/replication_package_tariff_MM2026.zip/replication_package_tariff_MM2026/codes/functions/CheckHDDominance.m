function [checkDom, tariff_col] = CheckHDDominance(B_draw, A0tilde, y, exog, p, n, ...
                                                      h_dom, anchor_shk_idx, anchor_signs, ...
                                                      tau_idx, neer_idx, ...
                                                      pindown_shk_idx, pindown_sign)
checkDom   = 0;
tariff_col = 0;

nexog = size(exog, 2);
B     = B_draw(nexog+1:end, :)';
c     = B_draw(1:nexog, :)';

shocks = get_shocks(y, exog, A0tilde, c, B, p);

IRFs = getIRFs(B_draw, A0tilde, exog, n, p, h_dom);

n_anchors = length(anchor_shk_idx);

HD_tau  = zeros(n_anchors, n);

for a = 1:n_anchors
    t_star = anchor_shk_idx(a);
    Tstart = t_star - h_dom;
    Tend   = t_star;

    if Tstart < 1   % insufficient lags for this horizon
        return;
    end

    HD_tau(a,:)  = getHDs_fast(IRFs, n, shocks(Tstart:Tend, :), tau_idx)';
end

for k = 1:n

    other = setdiff(1:n, k);

    dom_ok = true;
    for a = 1:n_anchors
        if sign(shocks(anchor_shk_idx(a), k)) ~= anchor_signs(a)
            dom_ok = false;
            break;
        end
        h_k      = HD_tau(a, k);
        H_other  = HD_tau(a, other);
        same_dir = H_other(sign(H_other) == sign(h_k));
        if ~isempty(same_dir) && abs(h_k) <= max(abs(same_dir))
            dom_ok = false;
            break;
        end
    end
    if ~dom_ok; continue; end

    if sign(shocks(pindown_shk_idx, k)) ~= pindown_sign; continue; end

    checkDom   = 1;
    tariff_col = k;
    return;

end

end
