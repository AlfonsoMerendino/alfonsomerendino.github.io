function y = year(d) 

if nargin < 1 
  error('finance:year:missingInputs','Please enter D.') 
end 
if ischar(d) 
  d = datenum(d); 
end 
 
c = datevec(d(:));
y = c(:,1); 
if ~ischar(d) 
  y = reshape(y,size(d)); 
end 

