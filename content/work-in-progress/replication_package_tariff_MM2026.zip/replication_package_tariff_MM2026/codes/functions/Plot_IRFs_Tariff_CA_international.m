labels = struct();

labels.log_gdp.title              = 'Real GDP';
labels.log_gdp.unit               = 'Percent (\%)';

labels.cpi.title                  = 'CPI inflation (y-o-y)';
labels.cpi.unit                   = 'Percentage points';

labels.log_neer.title             = 'NEER';
labels.log_neer.unit              = 'Percent (\%)';

labels.trade_balance_ngdp.title   = 'Trade balance / GDP';
labels.trade_balance_ngdp.unit    = 'Percentage points';

labels.macro_unc100.title         = 'Macro uncertainty';
labels.macro_unc100.unit          = 'Percent (\%)';

labels.fed_funds.title            = 'Federal funds rate';
labels.fed_funds.unit             = 'Percentage points';

labels.log_ea_gdp.title           = 'EA Real GDP';
labels.log_ea_gdp.unit            = 'Percent (\%)';

labels.ea_cpi.title               = 'EA HICP inflation (y-o-y)';
labels.ea_cpi.unit                = 'Percentage points';

labels.ea_euribor.title           = 'EA 3-months EURIBOR';
labels.ea_euribor.unit            = 'Percentage points';

labels.weighted_tau.title         = 'U.S. Weighted import tariffs';
labels.weighted_tau.unit          = 'Percentage points';

saved_output = fullfile(fileparts(mfilename('fullpath')), '..', '..', 'output', 'extracted_shocks', 'full_identification_output_SignImports_international.mat');

if ~exist('Draws_IRFs', 'var') || ~exist('varNames', 'var')
    if exist(saved_output, 'file')
        fprintf('Loading saved identification output from\n  %s\n', saved_output);
        S = load(saved_output, 'Draws_IRFs', 'varNames');
        Draws_IRFs = S.Draws_IRFs;
        varNames   = S.varNames;
        clear S
    else
        error(['Draws_IRFs/varNames not in workspace and saved file not found:\n  %s\n', ...
               'Run D3b_BVAR_international.m first.'], saved_output);
    end
end

if ~exist('tau_idx', 'var')
    tau_idx = find(strcmpi(varNames, 'weighted_tau'));
    if isempty(tau_idx)
        error('tau_idx is not defined and weighted_tau not found in varNames.');
    end
end

if ~exist('hmax_plot', 'var')
    hmax_plot = 15;
end

impact_draws = squeeze(Draws_IRFs(tau_idx, 1, 1, :));
impact_med   = median(impact_draws);

if ~isfinite(impact_med) || abs(impact_med) < 1e-12
    warning('Plot_IRFs_Tariff_CA_international: tariff impact is zero/invalid — no normalisation applied.');
    scale = 1;
else
    scale = 1 / impact_med;
end

desired_order = {'log_ea_gdp', ...
                 'ea_cpi', ...
                 'ea_euribor', ...
                 'weighted_tau'};

plot_order = {};

for vi = 1:numel(desired_order)

    entry   = desired_order{vi};
    idx_tmp = find(strcmpi(varNames, entry));

    if ~isempty(idx_tmp)
        plot_order{end+1} = idx_tmp;
    else
        warning('Variable "%s" not found in varNames. Skipping this panel.', entry);
    end

end

set(groot, 'defaultAxesTickLabelInterpreter', 'latex');
set(groot, 'defaultTextInterpreter',          'latex');
set(groot, 'defaultLegendInterpreter',        'latex');
set(groot, 'defaultAxesFontName',             'Times New Roman');
set(groot, 'defaultTextFontName',             'Times New Roman');

fig = figure('Color', 'w', ...
             'Units', 'pixels', ...
             'Position', [100 100 900 750]);

tiledlayout(2, 2, ...
            'Padding', 'compact', ...
            'TileSpacing', 'compact');

horizons = (0:hmax_plot)';
xfill    = [horizons; flipud(horizons)];

for pp = 1:numel(plot_order)

    ii = plot_order{pp};
    ax = nexttile;

    hold(ax, 'on');

    all_irfs = squeeze(Draws_IRFs(ii, 1, 1:hmax_plot+1, :)) * scale;

    med_raw = median(all_irfs, 2);
    lb90    = quantile(all_irfs, 0.05, 2);
    ub90    = quantile(all_irfs, 0.95, 2);
    lb68    = quantile(all_irfs, 0.16, 2);
    ub68    = quantile(all_irfs, 0.84, 2);

    fp90 = fill(ax, xfill, [lb90; flipud(ub90)], ...
                [0.65 0.80 0.95], ...
                'EdgeColor', 'none');
    fp90.FaceAlpha = 0.45;

    fp68 = fill(ax, xfill, [lb68; flipud(ub68)], ...
                [0.40 0.60 0.85], ...
                'EdgeColor', 'none');
    fp68.FaceAlpha = 0.55;

    plot(ax, horizons, med_raw, ...
         'Color', [0 0.4470 0.7410], ...
         'LineWidth', 2);

    yline(ax, 0, '-', ...
          'Color', [0.5 0.5 0.5], ...
          'LineWidth', 0.8);

    key = lower(varNames{ii});

    if isfield(labels, key)
        ttxt = labels.(key).title;
        ytxt = labels.(key).unit;
    else
        ttxt = varNames{ii};
        ytxt = '';
    end

    title(ax, ['\textbf{' ttxt '}'], ...
          'FontSize', 26, 'FontName', 'Times New Roman');
    xlabel(ax, '\textrm{Quarters}', ...
           'FontSize', 20, 'FontName', 'Times New Roman');

    if ~isempty(ytxt)
        ylabel(ax, ['\textrm{' ytxt '}'], ...
               'FontSize', 20, 'FontName', 'Times New Roman');
    end

    set(ax, 'Box', 'off', 'TickDir', 'out', ...
            'Layer', 'top', ...
            'XGrid', 'off', 'YGrid', 'off', ...
            'FontSize', 17, 'FontName', 'Times New Roman', ...
            'LineWidth', 1.0);

    xlim(ax, [0 hmax_plot]);

end

out_dir = fullfile(fileparts(mfilename('fullpath')), '..', '..', 'output');

if ~exist(out_dir, 'dir')
    mkdir(out_dir);
end

if ~exist('plot_fname', 'var')
    plot_fname = 'IRFs_Tariff_international.png';
end

fname = fullfile(out_dir, plot_fname);

exportgraphics(fig, fname, 'Resolution', 300);

fprintf('IRF plot saved to %s\n', fname);
