function x = LogAbsDet(X)

[~,U,~]=lu(X);
n=size(U,1);
x=0.0;
for i=1:n
    if U(i,i) == 0.0
        x=-inf;
        return;
    end
    x=x+log(abs(U(i,i)));
end
    