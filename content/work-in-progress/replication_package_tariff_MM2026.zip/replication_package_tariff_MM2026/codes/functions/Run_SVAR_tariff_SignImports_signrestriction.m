%  Sampler ── SIGN-RESTRICTED VARIANT of Run_SVAR_tariff_SignImports.m
%  Created 2026-08-23.  Identical to that file except for the impact-loading
%  sign restriction on the tariff shock (b_sign / b_tol) marked ADDED below.
%  Called by D2a_BVAR_signrestriction.m.

load(datafile)

if isempty(panelselect)
    panelselect = 1:size(data,2);
end

if ~exist('startQuarter', 'var'), startQuarter = 1; end
if ~exist('endQuarter',   'var'), endQuarter   = 4; end

dates_yq  = year(dates) + (quarter(dates) - 1) / 4;
start_yq  = startYear + (startQuarter - 1) / 4;
end_yq    = endYear   + (endQuarter   - 1) / 4;
mask      = dates_yq >= start_yq & dates_yq <= end_yq;

y     = data(mask, panelselect);
dates = dates(mask, :);

varNames = varNames(panelselect);

[T, n] = size(y);

if constant == 1
    exog = [ones(size(y,1),1) exog];
end

disp('OK');

K = n*p + size(exog,2);

[~, ~, posteriors] = BVAR(y, exog, p, prior_settings, 1);

Beta_mean = reshape(posteriors.b_post, K, n);

if ~exist('SR',  'var'), SR  = {}; end
if ~exist('ZR',  'var'), ZR  = {}; end
if ~exist('NSR', 'var'), NSR = {}; end
if ~exist('EBR', 'var'), EBR = {}; end

hirfs = 0;
NS    = 2;

S = cell(n,1);
Z = cell(n,1);
for j = 1:n
    S{j} = zeros(0, n*NS);
    Z{j} = zeros(0, n*NS);
end

Ns = zeros(T, n);
Nc = zeros(T, T, n, n);

shockNames = varNames;

if ~exist('imp_idx',        'var'), error('imp_idx not defined in workspace.');        end
if ~exist('imp_sign_restr', 'var'), error('imp_sign_restr not defined in workspace.'); end
if ~exist('h_imp',          'var'), error('h_imp not defined in workspace.');          end
if h_imp < 1
    error('h_imp must be >= 1 (restriction applies at horizons 1..h_imp, not h=0).');
end

% ── Sign restrictions on the impact loading of the tariff shock ──
%  ADDED 2026-08-23 (this variant only).
%
%  b = IRF(:, tariff shock, h = 0) is the impact loading vector of the
%  identified tariff shock.  In this codebase A0tilde is the structural
%  contemporaneous-coefficient matrix (shocks = innovations * A0tilde), so
%  the impact loadings are the columns of inv(A0tilde)' = IRFs(:,:,1), NOT
%  the columns of A0tilde itself.
%
%  b_sign(i) = +1 / -1 requires b(i) > b_tol / b(i) < -b_tol; 0 leaves it free.
if ~exist('b_sign', 'var') || isempty(b_sign)
    b_sign = zeros(n,1);
end
b_sign = b_sign(:);
if numel(b_sign) ~= n
    error('b_sign must have %d elements (one per endogenous variable).', n);
end
if ~all(ismember(b_sign, [-1 0 1]))
    error('b_sign entries must be -1, 0 or +1.');
end
if ~exist('b_tol', 'var') || isempty(b_tol)
    b_tol = 0;
end
b_restr_idx  = find(b_sign ~= 0);
b_restr_sign = b_sign(b_restr_idx);
if ~isempty(b_restr_idx)
    fprintf('Impact-loading sign restrictions active on %d variable(s) (b_tol = %g).\n', ...
            numel(b_restr_idx), b_tol);
else
    warning('b_sign is all zeros: this run is identical to Run_SVAR_tariff_SignImports.');
end

anchor_shk_idx   = zeros(length(anchor_dates), 1);
for a = 1:length(anchor_dates)
    data_row = find(abs(dates - anchor_dates(a)) < 1);
    if isempty(data_row)
        error('Anchor quarter datenum=%.0f not found in sample.', anchor_dates(a));
    end
    if data_row - p < 1 + h_dominance
        error('Insufficient lags for anchor quarter %s at h_dominance=%d.', ...
              datestr(anchor_dates(a),'yyyy-QQ'), h_dominance);
    end
    anchor_shk_idx(a) = data_row - p;
end


Beta_save  = nan(K, n, numDesiredDraws);
Sigma_save = nan(n, n, numDesiredDraws);
A0_save    = nan(n, n, numDesiredDraws);
Q_save     = nan(n, n, numDesiredDraws);
w_save     = nan(1, numDesiredDraws);

numSavedDraws  = 0;
numAttempts    = 0;
numStableDraws = 0;

while numSavedDraws < numDesiredDraws

    tic

    Beta_temp  = nan(K, n, BetaSigmaTries, Qs_per_BetaSigma);
    Sigma_temp = nan(n, n, BetaSigmaTries, Qs_per_BetaSigma);
    A0_temp    = nan(n, n, BetaSigmaTries, Qs_per_BetaSigma);
    Q_temp     = nan(n, n, BetaSigmaTries, Qs_per_BetaSigma);
    w_temp     = nan(1,    BetaSigmaTries, Qs_per_BetaSigma);

    for worker = 1:BetaSigmaTries

        [B_draw, SIGMA_draw] = BVAR_1draw(posteriors);

        maxRoot = max(abs(getRoots(B_draw(size(exog,2)+1:end,:)')));

        if maxRoot <= 1
            numStableDraws = numStableDraws + 1;

            for Q_count = 1:Qs_per_BetaSigma

                [A0tilde_draw, Qdraw, uw] = SignAndZeroRestrictions( ...
                    B_draw, SIGMA_draw, p, exog, hirfs, S, Z, agnostic);

                if isfinite(A0tilde_draw(1,1))

                    [checkDom, tariff_col] = CheckHDDominance_signrestriction( ...
                        B_draw, A0tilde_draw, y, exog, p, n, ...
                        h_dominance, anchor_shk_idx, anchor_signs, ...
                        tau_idx, neer_idx);

                    if checkDom

                        perm         = [tariff_col, setdiff(1:n, tariff_col)];
                        A0tilde_draw = A0tilde_draw(:, perm);
                        Qdraw        = Qdraw(:, perm);

                        IRFs_imp = getIRFs(B_draw, A0tilde_draw, exog, n, p, h_imp);

                        % ADDED 2026-08-23: sign restriction on the impact
                        % loading b of the tariff shock.  Column 1 is the
                        % tariff shock after the permutation above, and
                        % IRFs_imp(:,1,1) is its h = 0 loading vector.
                        if ~isempty(b_restr_idx)
                            b_impact = IRFs_imp(b_restr_idx, 1, 1);
                            if any(b_restr_sign .* b_impact <= b_tol)
                                continue;
                            end
                        end

                        imp_ok = true;
                        for hh = 1:h_imp
                            if sign(IRFs_imp(imp_idx, 1, hh+1)) ~= imp_sign_restr
                                imp_ok = false;
                                break;
                            end
                        end
                        if ~imp_ok; continue; end

                        Beta_temp(:,:, worker, Q_count)  = B_draw;
                        Sigma_temp(:,:, worker, Q_count) = SIGMA_draw;
                        A0_temp(:,:,   worker, Q_count)  = A0tilde_draw;
                        Q_temp(:,:,    worker, Q_count)  = Qdraw;
                        w_temp(:,      worker, Q_count)  = uw;

                    end
                end

            end
        end
    end

    Beta_clean  = reshape(Beta_temp,  K, n, BetaSigmaTries*Qs_per_BetaSigma);
    Sigma_clean = reshape(Sigma_temp, n, n, BetaSigmaTries*Qs_per_BetaSigma);
    A0_clean    = reshape(A0_temp,    n, n, BetaSigmaTries*Qs_per_BetaSigma);
    Q_clean     = reshape(Q_temp,     n, n, BetaSigmaTries*Qs_per_BetaSigma);
    w_clean     = reshape(w_temp,     1,    BetaSigmaTries*Qs_per_BetaSigma);

    keep = isfinite(squeeze(A0_clean(1,1,:)));
    Beta_clean  = Beta_clean(:,:, keep);
    Sigma_clean = Sigma_clean(:,:,keep);
    A0_clean    = A0_clean(:,:,   keep);
    Q_clean     = Q_clean(:,:,    keep);
    w_clean     = w_clean(:,      keep);

    numAcceptedDraws = size(Beta_clean, 3);

    if numAcceptedDraws > 0
        idx_from = numSavedDraws + 1;
        idx_to   = numSavedDraws + numAcceptedDraws;
        Beta_save(:,:,  idx_from:idx_to) = Beta_clean;
        Sigma_save(:,:, idx_from:idx_to) = Sigma_clean;
        A0_save(:,:,    idx_from:idx_to) = A0_clean;
        Q_save(:,:,     idx_from:idx_to) = Q_clean;
        w_save(:,       idx_from:idx_to) = w_clean;

        numSavedDraws = numSavedDraws + numAcceptedDraws;
    end

    numAttempts = numAttempts + (BetaSigmaTries*Qs_per_BetaSigma);

    disp(['Attempted draws: ', num2str(numAttempts)])
    disp(['  Stable Beta draws: ', num2str(numStableDraws), ...
          ' / ', num2str(numAttempts/Qs_per_BetaSigma), ...
          '  (', num2str(100*numStableDraws/(numAttempts/Qs_per_BetaSigma), '%.1f'), '%)'])
    disp(['Successful draws: ', num2str(numSavedDraws)])
    toc

end

if ~isempty(ZR)
    resample    = randsample(numSavedDraws, numSavedDraws, true, w_save);
    Beta_save   = Beta_save(:,:,   resample);
    Sigma_save  = Sigma_save(:,:,  resample);
    A0_save     = A0_save(:,:,     resample);
    Q_save      = Q_save(:,:,      resample);
end


if ~isempty(NSR)
    disp('Checking Narrative Sign Restrictions')
    [Beta_narrative, Sigma_narrative, A0_narrative, weights_narrative] = ...
        CheckNarrativeAndReWeight(y, p, Beta_save, Sigma_save, A0_save, ...
                                  exog, Ns, Nc, nRepsWeights);
    numSavedNarrative = size(Beta_narrative, 3);
end

disp('Computing IRFs ...')

hmax = 20;

Draws_IRFs   = nan(n, n, hmax+1, numSavedDraws);
Draws_Shocks = nan(T-p, n, numSavedDraws);

parfor draw = 1:numSavedDraws

    IRFs = getIRFs(Beta_save(:,:,draw), A0_save(:,:,draw), exog, n, p, hmax);

    if ~isempty(cumulateWhich)
        IRFs(cumulateWhich,:,:) = cumsum(IRFs(cumulateWhich,:,:), 3);
    end

    Draws_IRFs(:,:,:,draw) = IRFs;

    BETA = Beta_save(:,:,draw);
    B    = BETA(size(exog,2)+1:end,:)';
    c    = BETA(1:size(exog,2),:)';
    A0   = A0_save(:,:,draw);

    shocks = get_shocks(y, exog, A0, c, B, p);
    Draws_Shocks(:,:,draw) = shocks;

end

if ~isempty(NSR)

    disp('Computing IRFs for narrative sign restrictions')

    numSavedNarrative    = size(Beta_narrative, 3);
    Draws_IRFs_narrative = nan(n, n, hmax+1, numSavedNarrative);
    Draws_Shocks_narrative = nan(T-p, n, numSavedNarrative);

    parfor draw = 1:numSavedNarrative

        IRFs = getIRFs(Beta_narrative(:,:,draw), A0_narrative(:,:,draw), exog, n, p, hmax);

        if ~isempty(cumulateWhich)
            IRFs(cumulateWhich,:,:) = cumsum(IRFs(cumulateWhich,:,:), 3);
        end

        Draws_IRFs_narrative(:,:,:,draw) = IRFs;

        BETA = Beta_narrative(:,:,draw);
        B    = BETA(size(exog,2)+1:end,:)';
        c    = BETA(1:size(exog,2),:)';
        A0   = A0_narrative(:,:,draw);

        shocks = get_shocks(y, exog, A0, c, B, p);
        Draws_Shocks_narrative(:,:,draw) = shocks;

    end
end
