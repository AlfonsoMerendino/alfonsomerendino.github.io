function r = mvnrnd(mu, Sigma, n)

if nargin < 3 || isempty(n), n = 1; end
mu = mu(:).';
d  = numel(mu);
[R, p] = chol(Sigma);
if p > 0                         
    [V, D] = eig(full((Sigma + Sigma')/2));
    R = diag(sqrt(max(real(diag(D)), 0))) * V.';
end
r = mu(ones(n,1), :) + randn(n, d) * R;
end
