*===============================================================================
* Standardized U.S. import tariff q/q changes with q-o-q narrative tariff dates
*
* Baseline set:
*   2018Q4, 2025Q2
*
* Extended robustness set:
*   2018Q4, 2019Q3, 2019Q4, 2025Q2
*===============================================================================

clear all
set more off

if "$dir" == "" global dir = cond(substr("`c(pwd)'",-5,5)=="codes", substr("`c(pwd)'",1,length("`c(pwd)'")-6), "`c(pwd)'")
global dataset "$dir/dataset"
global figures "$dir/output"

cd "$dir"
capture graph set window fontface "Garamond"

*---------------------------------------------*
* Colour palette
*---------------------------------------------*
local c_tau       "0 76 153"      // blue line:   weighted_tau (Franconi Hack)
local c_sgu       "230 120 20"    // orange line: weighted_tau_SGU
local c_tri       "190 190 190"      // grey line: tri
local c_event     "0 45 120"      // dark blue for all event lines and labels

local c_paper     "230 99 14"     // baseline events
local c_base      "0 76 153"      // robustness additions
local c_bar       "navy"

*---------------------------------------------*
* Load and prepare data
*---------------------------------------------*
use "$dataset/data.dta", clear

keep date weighted_tau weighted_tau_SGU neer struct_tpu_sv_fullcalib tpu tri

foreach v in weighted_tau weighted_tau_SGU neer struct_tpu_sv_fullcalib tpu tri {
    capture confirm numeric variable `v'
    if _rc {
        destring `v', replace force
    }
}

capture confirm numeric variable date
if !_rc {
    gen double qdate = date
}
else {
    gen double qdate = quarterly(date, "YQ")
}

format qdate %tq
drop if missing(qdate)

collapse (mean) weighted_tau weighted_tau_SGU neer struct_tpu_sv_fullcalib tpu tri, by(qdate)

tsset qdate

*---------------------------------------------*
* Quarter-on-quarter changes
*---------------------------------------------*
gen double d_weighted_tau     = D.weighted_tau
gen double d_weighted_tau_SGU = D.weighted_tau_SGU
gen double d_tri              = D.tri
gen double d_neer_bp          = 100*(neer/L.neer - 1)

label var d_weighted_tau     "q/q change in weighted_tau"
label var d_weighted_tau_SGU "q/q change in weighted_tau_SGU"
label var d_tri              "q/q change in tri"

*---------------------------------------------*
* Standardize q/q changes over available sample
*---------------------------------------------*
quietly summarize d_weighted_tau if !missing(d_weighted_tau)
local mu_tau = r(mean)
local sd_tau = r(sd)

quietly summarize d_weighted_tau_SGU if !missing(d_weighted_tau_SGU)
local mu_sgu = r(mean)
local sd_sgu = r(sd)

quietly summarize d_tri if !missing(d_tri)
local mu_tri = r(mean)
local sd_tri = r(sd)

gen double z_d_weighted_tau     = (d_weighted_tau     - `mu_tau') / `sd_tau'
gen double z_d_weighted_tau_SGU = (d_weighted_tau_SGU - `mu_sgu') / `sd_sgu'
gen double z_d_tri              = (d_tri              - `mu_tri') / `sd_tri'

label var z_d_weighted_tau     "weighted_tau"
label var z_d_weighted_tau_SGU "weighted_tau_SGU"
label var z_d_tri              "tri"


********************************************************************************
* TABLE 1 - Narrative dates for tariff shock identification
********************************************************************************

local tab_start = tq(1990q1)
local tab_end   = tq(2025q4)

quietly summarize d_weighted_tau if inrange(qdate, `tab_start', `tab_end')
local mu_tab = r(mean)
local sd_tab = r(sd)

capture drop z_tab
gen double z_tab = (d_weighted_tau - `mu_tab') / `sd_tab'
label var z_tab "z(D.weighted_tau), standardized on 1990q1-2025q4"

local q_list3  = tq(2018q4)
local q_libday = tq(2025q2)
local q_list4a = tq(2019q3)
local q_airbus = tq(2019q4)

foreach ev in list3 libday list4a airbus {
    quietly summarize z_tab if qdate == `q_`ev'', meanonly
    local zv = r(mean)
    if missing(`zv') {
        display as error "z(Delta tau) missing at `ev' - check the table window."
    }
    local zs = cond(`zv' < 0, "-", "+")
    local za = abs(`zv')
    if `za' >= 10 {
        local zt = trim(string(`za', "%9.1f"))
    }
    else {
        local zt = trim(string(`za', "%9.2f"))
    }
    local z_`ev' "`zs'`zt'"
}

display _newline as text "Table 1 z(Delta tau), standardized on 1990q1-2025q4:"
display as text "  2018q4 = " as result "`z_list3'"  ///
        as text "   2025q2 = " as result "`z_libday'" ///
        as text "   2019q3 = " as result "`z_list4a'" ///
        as text "   2019q4 = " as result "`z_airbus'"

* Characters Stata would otherwise read as macro delimiters
local D  = char(36)                // dollar sign, math delimiter
local DS = char(92) + char(36)     // backslash + dollar, LaTeX escaped dollar
local B  = char(96)                // opening quote character
local Q  = char(39)                // closing quote character

capture file close tex1
file open tex1 using "$figures/table1_narrative_dates.tex", write replace text

file write tex1 "\begin{table}[H]" _n
file write tex1 "\begin{threeparttable}" _n
file write tex1 "{\centering" _n
file write tex1 "\caption{Narrative dates for tariff shock identification}" _n
file write tex1 "\label{tab:narrative-dates}" _n
file write tex1 "\begin{tabular}{lcl}" _n
file write tex1 "\toprule" _n
file write tex1 "Date & `D'z(\Delta\tau)`D' (std.) & Narrative event \\" _n
file write tex1 "\midrule" _n
file write tex1 "\multicolumn{3}{l}{\textit{Panel A: Baseline}} \\[2pt]" _n
file write tex1 "2018Q4 & `D'`z_list3'`D' & \S\,301 List~3, `DS'200B at 10\% (Sept.\ 24, 2018) \\" _n
file write tex1 "2025Q2 & `D'`z_libday'`D' & `B'`B'Liberation Day`Q'`Q' reciprocal tariffs (Apr.\ 2, 2025) \\" _n
file write tex1 "\addlinespace[3pt]" _n
file write tex1 "\midrule" _n
file write tex1 "\multicolumn{3}{l}{\textit{Panel B: Extended}} \\[2pt]" _n
file write tex1 "2019Q3 & `D'`z_list4a'`D' & \S\,301 List~4A, `DS'112B at 15\% (Sept.\ 1, 2019) \\" _n
file write tex1 "\addlinespace[2pt]" _n
file write tex1 "2019Q4 & `D'`z_airbus'`D' & WTO-Airbus countermeasures (Oct.\ 18, 2019) \\" _n
file write tex1 "       &         & and \S\,301 List~4A continuation \\" _n
file write tex1 "\bottomrule" _n
file write tex1 "\end{tabular}" _n
file write tex1 "\par}" _n
file write tex1 "\end{threeparttable}" _n
file write tex1 "\end{table}" _n

file close tex1

display as text "Table 1 written to " as result "$figures/table1_narrative_dates.tex"





********************************************************************************
* Three standardized tariff indices IN LEVELS since 1990, no event lines,
* with two text-boxes at the top reporting Corr(WIT1, TRI) and Corr(WIT1, WIT2)
* over the full sample.
********************************************************************************

*---------------------------------------------*
* Colour palette
*---------------------------------------------*
local c_tau       "0 76 153"      // blue line:   weighted_tau (Franconi Hack)
local c_sgu       "230 120 20"    // orange line: weighted_tau_SGU
local c_tri       "190 190 190"      // grey line: tri
local c_event     "0 45 120"      // dark blue for all event lines and labels

local c_paper     "230 99 14"     // baseline events
local c_base      "0 76 153"      // robustness additions
local c_bar       "navy"

preserve
    use "$dataset/data.dta", clear

    keep date weighted_tau weighted_tau_SGU tri

    foreach v in weighted_tau weighted_tau_SGU tri {
        capture confirm numeric variable `v'
        if _rc destring `v', replace force
    }

    capture confirm numeric variable date
    if !_rc {
        gen double qdate = date
    }
    else {
        gen double qdate = quarterly(date, "YQ")
    }
    format qdate %tq
    drop if missing(qdate)

    collapse (mean) weighted_tau weighted_tau_SGU tri, by(qdate)

    keep if qdate >= tq(1990q1)
    tsset qdate

    * Standardize over the 1990+ sample
    foreach v in weighted_tau weighted_tau_SGU tri {
        quietly summarize `v'
        gen double z_`v' = (`v' - r(mean)) / r(sd)
    }

    rename z_weighted_tau     z_wit1
    rename z_weighted_tau_SGU z_wit2
    rename z_tri              z_tri

    * Correlations over the full sample shown in the plot
    quietly corr z_wit1 z_tri
    local rho_wit1_tri  : display %4.2f r(rho)
    quietly corr z_wit1 z_wit2
    local rho_wit1_wit2 : display %4.2f r(rho)

    * y-range so the text-boxes sit clearly above the lines
    quietly summarize z_wit1
    local ymax = r(max)
    quietly summarize z_wit2
    local ymax = max(`ymax', r(max))
    quietly summarize z_tri
    local ymax = max(`ymax', r(max))
    quietly summarize z_wit1
    local ymin = r(min)
    quietly summarize z_wit2
    local ymin = min(`ymin', r(min))
    quietly summarize z_tri
    local ymin = min(`ymin', r(min))

local ytop    = 10
local ybottom = floor(`ymin') - 1
local ytext   = 9.35

    quietly summarize qdate
    local qmin = r(min)
    local qmax = r(max)
    local q_box1 = `qmin' + 0.25*(`qmax' - `qmin')
    local q_box2 = `qmin' + 0.75*(`qmax' - `qmin')

twoway ///
    (line z_tri  qdate, lcolor("`c_tri'") lwidth(medthick) lpattern(solid)) ///
    (line z_wit2 qdate, lcolor("`c_sgu'") lwidth(medthick) lpattern(dash))  ///
    (line z_wit1 qdate, lcolor("`c_tau'") lwidth(thick)    lpattern(solid)), ///
    legend(order(3 "WIT1" 2 "WIT2" 1 "TRI") ///
        rows(1) position(6) ///
        region(fcolor(white) lcolor(black) lwidth(thin)) ///
        size(6)) ///
    text(`ytext' `q_box1' ///
        "Corr(WIT1, TRI) = `rho_wit1_tri'", ///
        size(6.5) color(black) ///
        box bcolor(white) lcolor(black) lwidth(thin) ///
        margin(vsmall) just(center) place(c)) ///
    text(`ytext' `q_box2' ///
        "Corr(WIT1, WIT2) = `rho_wit1_wit2'", ///
        size(6.5) color(black) ///
        box bcolor(white) lcolor(black) lwidth(thin) ///
        margin(vsmall) just(center) place(c)) ///
    ytitle("US import tariffs (std.)", size(6.8)) ///
    xtitle("") ///
    ylabel(`ybottom'(3)`ytop', angle(0) nogrid noticks labsize(6.7)) ///
    xlabel(`=tq(1990q1)'(20)`=tq(2024q1)', ///
        format(%tqCY) nogrid noticks labsize(6.7)) ///
    xscale(range(`=tq(1990q1)' `=tq(2026q1)')) ///
    yscale(range(`ybottom' `ytop')) ///
    ysize(4.2) xsize(8.8) ///
    graphregion(color(white)) bgcolor(white) ///
    plotregion(margin(small))
	
    graph export "$figures/tariff_indices_levs_since1990_std.png", ///
        replace width(2600) height(1250)
restore



keep if inrange(qdate, tq(2016q1), tq(2025q4))

*---------------------------------------------*
* Event quarters
*---------------------------------------------*

* Baseline set
local q_list3  = tq(2018q4)
local q_libday = tq(2025q2)

* Extended robustness additions
local q_list4a = tq(2019q3)
local q_airbus = tq(2019q4)

local baseline_events  "`q_list3' `q_libday'"
local extended_events  "`q_list4a' `q_airbus'"

*---------------------------------------------*
* Automatic y-axis range with label space
*---------------------------------------------*
egen double z_min = rowmin(z_d_weighted_tau z_d_weighted_tau_SGU z_d_tri)
egen double z_max = rowmax(z_d_weighted_tau z_d_weighted_tau_SGU z_d_tri)

quietly summarize z_min
local ymin_raw = r(min)

quietly summarize z_max
local ymax_raw = r(max)

local ybottom = floor(`ymin_raw' - 0.75)
local ytop    = 10

drop z_min z_max

local y_lab1 = `ytop' - 0.25
local y_lab2 = `ytop' - 0.85
local y_lab3 = `ytop' - 3.45
local y_lab4 = `ytop' - 5.05

*---------------------------------------------*
* Print z_d_weighted_tau at event quarters
*---------------------------------------------*
display _newline as text "z_d_weighted_tau at event quarters (full-sample standardization, as in Table 1 and Figure 2):"
foreach q in `q_list3' `q_list4a' `q_airbus' `q_libday' {
    quietly summarize z_d_weighted_tau if qdate == `q', meanonly
    local qlab : display %tq `q'
    display as text "  " "`qlab'" "   z = " as result %9.4f r(mean)
}

*---------------------------------------------*
* Plot 1: three tariff-change series
*---------------------------------------------*
twoway ///
    (line z_d_tri qdate, ///
        lcolor("`c_tri'") ///
        lpattern(solid) ///
        lwidth(thick)) ///
	(line z_d_weighted_tau_SGU qdate, ///
        lcolor("`c_sgu'") ///
        lpattern(solid) ///
        lwidth(thick)) ///
    (line z_d_weighted_tau qdate, ///
        lcolor("`c_tau'") ///
        lpattern(solid) ///
        lwidth(thick)) ///
    , ///
    legend(order( 1 "TRI"  3 "WIT1" 2 "WIT2") ///
           cols(3) ///
           ring(1) ///
           pos(6) ///
           size(large) ///
           region(lcolor(black) fcolor(white))) ///
    yline(0, lcolor(black) lwidth(thin)) ///
    xline(`baseline_events', ///
        lcolor("`c_event'") ///
        lpattern(solid)) ///
    xline(`extended_events', ///
        lcolor("`c_event'") ///
        lpattern(dash)) ///
    text(`y_lab1' `=`q_list3'-0.25' ///
        "2018Q4(+): List 3", ///
        size(medlarge) color("`c_event'") just(right) place(w)) ///
    text(`y_lab3' `=`q_list4a'+0.25' ///
        "2019Q3(+): List 4A", ///
        size(medlarge) color("`c_event'") just(left) place(e)) ///
    text(`y_lab4' `=`q_airbus'+0.25' ///
        "2019Q4(+): Airbus", ///
        size(medlarge) color("`c_event'") just(left) place(e)) ///
    text(`y_lab2' `=`q_libday'-0.25' ///
        "2025Q2(+): Liberation Day", ///
        size(medlarge) color("`c_event'") just(right) place(w)) ///
    ytitle("US import tariffs, q/q changes (std.)", size(5)) ///
    xtitle("") ///
    ylabel(`ybottom'(4)`ytop', angle(0) nogrid noticks labsize(6)) ///
    xlabel(`=tq(2017q1)'(8)`=tq(2025q1)', ///
        format(%tqCY) ///
        nogrid ///
        noticks ///
        labsize(7)) ///
    xscale(range(`=tq(2017q1)' `=tq(2026q1)')) ///
    ysize(4.2) ///
    xsize(8.8) ///
    graphregion(color(white)) ///
    bgcolor(white) ///
    plotregion(margin(small))

graph export "$figures/tariff_weighted_and_SGU_qoq_NEWevents.png", ///
    replace width(2600) height(1250)
	
	
