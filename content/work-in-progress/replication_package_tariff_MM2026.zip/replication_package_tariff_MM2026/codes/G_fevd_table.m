%% FEVD

clear; clc;

%% ── PATHS ────────────────────────────────────────────────────────────────
codeDir    = fileparts(mfilename('fullpath'));
funpath    = fullfile(codeDir, 'functions');
outdir     = fullfile(codeDir, '..', 'output', 'output_hd_reer');
cachefile  = fullfile(outdir, 'estimation_cache_SignImports_reer.mat');
fevdfile   = fullfile(outdir, 'FEVD_tariff_results.mat');
texfile    = fullfile(outdir, 'FEVD_tariff_table.tex');

addpath(funpath);

assert(exist(cachefile, 'file') == 2, ...
    'estimation_cache_SignImports_reer.mat not found — run F_historical_decomposition.m first.');

%% ── SETTINGS ─────────────────────────────────────────────────────────────
horizons = [1, 5, 10, 15];   % forecast steps ahead
H_max    = max(horizons);

recompute_fevd = false;   % set to true to recompute from scratch

%% ── LOAD ESTIMATION CACHE ────────────────────────────────────────────────
fprintf('Loading estimation cache ...\n');
S = load(cachefile, 'Beta_save', 'A0_save', 'exog', 'n', 'p', 'varNames', 'numSavedDraws');

% Variable indices
var_names_plot  = {'log_reer', 'log_gdp', 'cpi', 'trade_balance_ngdp'};
var_labels_plot = {'REER', 'Real GDP', 'CPI Inflation', 'Trade Balance / GDP'};

nv = numel(var_names_plot);
var_cols = zeros(1, nv);
for vi = 1:nv
    idx = find(strcmpi(S.varNames, var_names_plot{vi}));
    assert(~isempty(idx), 'Variable "%s" not found in varNames.', var_names_plot{vi});
    var_cols(vi) = idx;
end

%% ── COMPUTE / LOAD FEVD ──────────────────────────────────────────────────
if ~recompute_fevd && exist(fevdfile, 'file')

    fprintf('Loading cached FEVD results ...\n  %s\n', fevdfile);
    load(fevdfile, 'FEVD_all');

else

    Nd   = S.numSavedDraws;
    n    = S.n;
    p    = S.p;
    nh   = numel(horizons);

    FEVD_all = nan(nv, nh, Nd);

    Beta_save_par = S.Beta_save;
    A0_save_par   = S.A0_save;
    exog_par      = S.exog;
    vc            = var_cols;
    hz            = horizons;

    fprintf('Computing FEVD (%d draws) ...\n', Nd);

    parfor draw = 1:Nd
        irf_d = getIRFs(Beta_save_par(:,:,draw), A0_save_par(:,:,draw), ...
                        exog_par, n, p, H_max - 1);

        fevd_draw = nan(nv, numel(hz));
        for vi = 1:nv
            var_i = vc(vi);
            for hi = 1:numel(hz)
                H = hz(hi);
                num   = sum(irf_d(var_i, 1, 1:H).^2, 3);              % tariff shock
                denom = sum(sum(irf_d(var_i, :, 1:H).^2, 2), 3);     % all shocks
                fevd_draw(vi, hi) = double(num) / double(denom);
            end
        end
        FEVD_all(:, :, draw) = fevd_draw;
    end

    fprintf('Done.\n');
    save(fevdfile, 'FEVD_all', '-v7.3');
    fprintf('Cached FEVD to:\n  %s\n', fevdfile);

end

%% ── POSTERIOR STATISTICS ─────────────────────────────────────────────────
FEVD_med = median(FEVD_all, 3) * 100;          % percent
FEVD_lb  = quantile(FEVD_all, 0.16, 3) * 100;  % 68% CI lower
FEVD_ub  = quantile(FEVD_all, 0.84, 3) * 100;  % 68% CI upper

%% ── BUILD LATEX TABLE ────────────────────────────────────────────────────
nv = numel(var_labels_plot);
nh = numel(horizons);

lines = {};
lines{end+1} = '\begin{table}[H]';
lines{end+1} = '{\centering';
lines{end+1} = '\caption{FEVD: Share Explained by the Tariff Shock}';
lines{end+1} = '\label{tab:fevd_tariff}';
lines{end+1} = '\scalebox{0.95}{%';
lines{end+1} = ['\begin{tabular}{l' repmat('c', 1, nh) '}'];
lines{end+1} = '\toprule';
lines{end+1} = [' & \multicolumn{' num2str(nh) '}{c}{Forecast horizon (quarters)} \\'];
lines{end+1} = ['\cmidrule(lr){2-' num2str(nh+1) '}'];

hdr = ' ';
for hi = 1:nh
    hdr = [hdr ' & ' num2str(horizons(hi))];
end
lines{end+1} = [hdr ' \\'];
lines{end+1} = '\midrule';

for vi = 1:nv
    row1 = var_labels_plot{vi};
    for hi = 1:nh
        row1 = [row1 ' & ' sprintf('%.1f', FEVD_med(vi, hi))];
    end
    lines{end+1} = [row1 ' \\'];

    row2 = ' ';
    for hi = 1:nh
        ci_str = sprintf('[%.1f,\\ %.1f]', FEVD_lb(vi, hi), FEVD_ub(vi, hi));
        row2 = [row2 ' & {\small ' ci_str '}'];
    end
    lines{end+1} = [row2 ' \\'];

    if vi < nv
        lines{end+1} = '[3pt]';
    end
end

lines{end+1} = '\bottomrule';
lines{end+1} = '\end{tabular}%';
lines{end+1} = '}';
lines{end+1} = '\par}';
lines{end+1} = ['\footnotesize{\textit{Notes}: Entries report the posterior median share of the ' ...
    'forecast error variance (in percent) accounted for by the tariff shock. ' ...
    '68\% credible intervals in brackets.}'];
lines{end+1} = '\end{table}';

%% ── WRITE .tex FILE ──────────────────────────────────────────────────────
fid = fopen(texfile, 'w');
assert(fid ~= -1, 'Could not open %s for writing.', texfile);
for k = 1:numel(lines)
    fprintf(fid, '%s\n', lines{k});
end
fclose(fid);
fprintf('LaTeX table saved to:\n  %s\n', texfile);

%% ── PRINT TO CONSOLE ─────────────────────────────────────────────────────
fprintf('\n');
for k = 1:numel(lines)
    fprintf('%s\n', lines{k});
end
