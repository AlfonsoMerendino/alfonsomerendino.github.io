*=============================================================================*
* Aggregate TPU vs S-TPU index
*=============================================================================*

clear all
set more off

if "$dir" == "" global dir = cond(substr("`c(pwd)'",-5,5)=="codes", substr("`c(pwd)'",1,length("`c(pwd)'")-6), "`c(pwd)'")
global data    "$dir/sources"
global dataset "$dir/dataset"
global figures "$dir/output"

capture graph set window fontface "Garamond"
capture graph drop _all

*-------------------------------------------------------------*
* Aggregate TPU on WIT1
*-------------------------------------------------------------*

import delimited "$dataset/SV_WIT1_STPU.csv", clear varnames(1) case(lower)

keep date_str sv_wit1_pctpts

gen date = quarterly(date_str, "YQ")
format date %tq
drop date_str

destring sv_wit1_pctpts, replace force

merge 1:1 date using "$dataset/data.dta", nogen

keep if inrange(date, tq(1990q1), tq(2025q4))

********************************************************************************
* Standardize variables on the plotted sample: 1990Q1-2025Q4
********************************************************************************

cap drop z_sv_wit1 z_struct_tpu_sv_fullcalib

egen z_sv_wit1 = std(sv_wit1_pctpts) ///
    if inrange(date, tq(1990q1), tq(2025q4)) ///
    & !missing(sv_wit1_pctpts)

egen z_struct_tpu_sv_fullcalib = std(struct_tpu_sv_fullcalib) ///
    if inrange(date, tq(1990q1), tq(2025q4)) ///
    & !missing(struct_tpu_sv_fullcalib)

*-------------------------------------------------------------*
* Percentile on plotted sample: top 30% of standardized S-TPU
*-------------------------------------------------------------*

centile z_struct_tpu_sv_fullcalib ///
    if inrange(date, tq(1990q1), tq(2025q4)) ///
    & !missing(z_struct_tpu_sv_fullcalib), centile(70)

local p70 = r(c_1)

display "p70(z S-TPU) = `p70'"

*-------------------------------------------------------------*
* Y range of the graph: use both standardized plotted series
*-------------------------------------------------------------*

quietly summarize z_sv_wit1 ///
    if inrange(date, tq(1990q1), tq(2025q4)) ///
    & !missing(z_sv_wit1), meanonly

local ymin = r(min)
local ymax = r(max)

quietly summarize z_struct_tpu_sv_fullcalib ///
    if inrange(date, tq(1990q1), tq(2025q4)) ///
    & !missing(z_struct_tpu_sv_fullcalib), meanonly

local ymin = min(`ymin', r(min))
local ymax = max(`ymax', r(max))

local ymin_plot = min(-2, `ymin')
local ymax_plot = max(9,  `ymax')

*-------------------------------------------------------------*
* Shaded region: top 30% of standardized S-TPU distribution
*-------------------------------------------------------------*

cap drop shade30_lo shade30_hi

gen double shade30_lo = .
gen double shade30_hi = .

replace shade30_lo = `ymin_plot' ///
    if z_struct_tpu_sv_fullcalib >= `p70' ///
    & !missing(z_struct_tpu_sv_fullcalib)

replace shade30_hi = `ymax_plot' ///
    if z_struct_tpu_sv_fullcalib >= `p70' ///
    & !missing(z_struct_tpu_sv_fullcalib)

sort date

*-------------------------------------------------------------*
* Figure
*-------------------------------------------------------------*

twoway ///
    (rbar shade30_lo shade30_hi date, ///
        barwidth(1) ///
        color(orange%28) ///
        lcolor(none)) ///
    (line z_sv_wit1 date, ///
        lpattern(dash) ///
        lcolor("0 112 188") ///
        lwidth(thick)) ///
    (line z_struct_tpu_sv_fullcalib date, ///
        lpattern(solid) ///
        lcolor("216 78 19") ///
        lwidth(thick)) ///
    , ///
    legend(order(2 "Aggregate TPU" 3 "S-TPU") ///
           cols(2) ///
           ring(1) ///
           pos(6) ///
           size(6) ///
           region(lcolor(black) lwidth(thin) fcolor(white))) ///
    yline(0, lcolor(black) lpattern(dash) lwidth(thin)) ///
    ytitle("TPU & S-TPU (std.)", size(7)) ///
    ylabel(0(2)8, angle(0) nogrid noticks labsize(6.7)) ///
    yscale(range(`ymin_plot' `ymax_plot')) ///
    xtitle("") ///
    xlabel(`=tq(1990q1)' `=tq(1996q1)' `=tq(2002q1)' ///
           `=tq(2008q1)' `=tq(2014q1)' `=tq(2020q1)' ///
           `=tq(2025q1)', ///
        format(%tqCY) nogrid noticks labsize(6.7)) ///
    xscale(range(`=tq(1990q1)' `=tq(2025q4)')) ///
    ysize(4.2) ///
    xsize(8.8) ///
    graphregion(color(white)) ///
    plotregion(color(white) margin(small)) ///
    bgcolor(white) ///
    name(sv_wit1_stpu_1990, replace)

graph export "$figures/z_sv_wit1_z_struct_tpu_sv_fullcalib_1990_shaded30.png", ///
    replace width(2600) height(1250)
