%% Plot HD_reer single

clear; clc;

%% ── PATHS ────────────────────────────────────────────────────────────────
codeDir = fileparts(mfilename('fullpath'));
funpath = fullfile(codeDir, 'functions');
outdir  = fullfile(codeDir, '..', 'output', 'output_hd_reer');
hdfile  = fullfile(outdir, 'HD_reer_results.mat');

addpath(funpath);

assert(exist(hdfile, 'file') == 2, ...
    'HD_reer_results.mat not found — run F_historical_decomposition.m first.');

%% ── LOAD REER HD ─────────────────────────────────────────────────────────
load(hdfile, 'HD_reer_med', 'HD_total_med', 'plot_dates', 'tariff_shock_col');
T_hd = numel(plot_dates);

%% ── STYLE ────────────────────────────────────────────────────────────────
set(groot, 'defaultAxesFontName',             'Times New Roman');
set(groot, 'defaultTextFontName',             'Times New Roman');
set(groot, 'defaultAxesFontSize',             17);
set(groot, 'defaultAxesLineWidth',            0.75);
set(groot, 'defaultAxesTickLabelInterpreter', 'latex');
set(groot, 'defaultTextInterpreter',          'latex');
set(groot, 'defaultLegendInterpreter',        'latex');

shock_colors = [0.8500 0.3250 0.0980;   % orange – tariff shock
                0.75   0.75   0.75  ];  % grey   – other shocks

%% ── X-TICK LABELS ────────────────────────────────────────────────────────
tick_step = 4 * round(T_hd / 28);
tick_idx  = 1 : tick_step : T_hd;
tick_labs = hd_ytick(plot_dates, tick_idx);

%% ── SHADED REGION BOUNDARIES ─────────────────────────────────────────────
shade_windows = [datenum(2018, 1, 1), datenum(2019, 12, 31);   % 2018Q1–2019Q4
                 datenum(2024, 1, 1), datenum(2025, 12, 31)];  % 2024Q1–2025Q4

shade_xidx = zeros(size(shade_windows));
for k = 1:size(shade_windows, 1)
    [~, shade_xidx(k, 1)] = min(abs(plot_dates - shade_windows(k, 1)));
    [~, shade_xidx(k, 2)] = min(abs(plot_dates - shade_windows(k, 2)));
end

%% ── NARRATIVE ANCHOR LINES ───────────────────────────────────────────────
anchor_dates = [datenum(2018, 10, 1);
                datenum(2025,  4, 1)];
anchor_xidx  = zeros(numel(anchor_dates), 1);
for k = 1:numel(anchor_dates)
    [~, anchor_xidx(k)] = min(abs(plot_dates - anchor_dates(k)));
end

%% ── FIGURE ───────────────────────────────────────────────────────────────
fig = figure('Color','w', 'Units','inches', 'Position',[1 1 12 6], 'Visible','on');
ax  = axes(fig);
hold(ax, 'on');

shade_alpha = 0.12;
shade_color = [0.2 0.4 0.8];

tariff_c   = HD_reer_med(:, tariff_shock_col);
other_c    = HD_total_med - tariff_c;
plot_data  = [tariff_c, other_c];

pos_mat = max(plot_data, 0);
neg_mat = min(plot_data, 0);

hb_pos = bar(ax, 1:T_hd, pos_mat, 'stacked', 'BarWidth', 0.9, 'EdgeColor','none');
for j = 1:2
    hb_pos(j).FaceColor        = shock_colors(j,:);
    hb_pos(j).HandleVisibility = 'off';
end
hb_neg = bar(ax, 1:T_hd, neg_mat, 'stacked', 'BarWidth', 0.9, 'EdgeColor','none');
for j = 1:2
    hb_neg(j).FaceColor        = shock_colors(j,:);
    hb_neg(j).HandleVisibility = 'off';
end

h_line = plot(ax, 1:T_hd, HD_total_med, 'k-', 'LineWidth', 1.5);

% Zero line and anchor verticals
yline(ax, 0, ':', 'Color',[0.35 0.35 0.35], 'LineWidth', 0.8, 'HandleVisibility','off');
for k = 1:numel(anchor_xidx)
    xline(ax, anchor_xidx(k), '--', 'Color',[0.7 0 0], 'LineWidth', 0.9, 'HandleVisibility','off');
end

yl = ylim(ax);
shade_labels = {'2018-19 Trade war', '2024-25 Trade war'};
for k = 1:size(shade_xidx, 1)
    x1 = shade_xidx(k,1) - 0.5;
    x2 = shade_xidx(k,2) + 0.5;
    hp = patch(ax, [x1 x2 x2 x1], [yl(1) yl(1) yl(2) yl(2)], shade_color, ...
               'FaceAlpha', shade_alpha, 'EdgeColor', 'none', 'HandleVisibility','off');
    uistack(hp, 'bottom');
    text(ax, (x1 + x2)/2, yl(2), shade_labels{k}, ...
         'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom', ...
         'FontSize', 12, 'FontName', 'Times New Roman', 'Interpreter', 'latex', ...
         'Color', shade_color, 'Clipping', 'off');
end
ylim(ax, yl);

hb_pos(1).HandleVisibility = 'on';
hb_pos(2).HandleVisibility = 'on';

title(ax, '\textbf{Real Effective Exchange Rate}', 'FontSize', 26, 'FontName', 'Times New Roman');
ylabel(ax, '\textrm{Percent (\%)}', 'FontSize', 20, 'FontName', 'Times New Roman');
ax.XTick              = tick_idx;
ax.XTickLabel         = tick_labs;
ax.XTickLabelRotation = 45;
xlim(ax, [0.5, T_hd + 0.5]);
ax.Box     = 'off';
ax.TickDir = 'out';
ax.Layer   = 'top';
ax.FontSize = 17;
disableDefaultInteractivity(ax);
ax.Toolbar.Visible = 'off';

%% ── LEGEND ───────────────────────────────────────────────────────────────
legend(ax, [hb_pos(1), hb_pos(2), h_line], ...
       {'\textrm{Tariff shock}', '\textrm{Other shocks}', ...
        '\textrm{Detrended REER}'}, ...
       'Orientation', 'horizontal', 'Box', 'on', 'FontSize', 18, ...
       'Location', 'southoutside');

%% ── SAVE ─────────────────────────────────────────────────────────────────
fname = fullfile(outdir, 'HD_reer_single.png');
exportgraphics(fig, fname, 'Resolution', 300);
fprintf('Saved: %s\n', fname);

%% =========================================================================
function labs = hd_ytick(dn_vec, idx)
    labs = cell(1, numel(idx));
    for ii = 1:numel(idx)
        d = dn_vec(idx(ii));
        if isdatetime(d); d = datenum(d); end
        dv       = datevec(d);
        labs{ii} = sprintf('%d', dv(1));
    end
end
