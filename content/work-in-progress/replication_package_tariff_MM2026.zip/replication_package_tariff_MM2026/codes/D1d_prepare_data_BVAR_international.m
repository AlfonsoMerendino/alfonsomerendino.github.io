%% Prepare dataset for international BVAR

clear; clc;

%% ── PATHS ──
codeDir = fileparts(mfilename('fullpath'));
rootDir = fileparts(codeDir);
datafile_xlsx = fullfile(rootDir, 'dataset', 'data.xlsx');
save_path     = fullfile(rootDir, 'dataset', 'TariffData_CA_international.mat');
%% ─────────────────────────────────────────────────────────────────────────

fprintf('Reading %s ...\n', datafile_xlsx);
opts = detectImportOptions(datafile_xlsx);
raw  = readtable(datafile_xlsx, opts);
headers = raw.Properties.VariableNames;

dates_str = raw{:, 1};

if ~iscell(dates_str)
    dates_str = cellstr(string(dates_str));
end

T_full    = numel(dates_str);
date_nums = NaN(T_full, 1);

for i = 1:T_full

    ds     = strtrim(dates_str{i});
    qmatch = regexp(ds, '^(\d{4})[qQ](\d)$', 'tokens');

    if ~isempty(qmatch)
        yr           = str2double(qmatch{1}{1});
        qt           = str2double(qmatch{1}{2});
        date_nums(i) = datenum(yr, (qt - 1) * 3 + 1, 1);
    end

end

% ── Select sample: 2002Q1 – 2025Q2 ───────────────────────────────────────
%  ea_cpi, ea_euribor and log_neer all start in 2002q1.
start_num   = datenum(2002, 1, 1);
end_num     = datenum(2025, 4, 1);   % 2025Q2
sample_mask = ~isnan(date_nums) & ...
              (date_nums >= start_num) & ...
              (date_nums <= end_num);

rawVarNames = {'log_imp', ...
               'exp_nominal', ...
               'imp_nominal', ...
               'ngdp', ...
               'log_gdp', ...
               'cpi', ...
               'macro_unc100', ...
               'log_neer', ...
               'weighted_tau', ...
               'fed_funds', ...
               'log_ea_gdp', ...
               'ea_cpi', ...
               'ea_euribor'};

rawidx = zeros(1, numel(rawVarNames));

for i = 1:numel(rawVarNames)

    idx = find(strcmpi(headers, rawVarNames{i}));

    if isempty(idx)
        error('Variable "%s" not found in %s.', rawVarNames{i}, datafile_xlsx);
    end

    rawidx(i) = idx;

end

raw_data = double(raw{sample_mask, rawidx});
dates    = date_nums(sample_mask);

[dates, sort_idx] = sort(dates);
raw_data = raw_data(sort_idx, :);

log_imp         = raw_data(:, strcmpi(rawVarNames, 'log_imp'));
exp_nominal     = raw_data(:, strcmpi(rawVarNames, 'exp_nominal'));
imp_nominal     = raw_data(:, strcmpi(rawVarNames, 'imp_nominal'));
ngdp            = raw_data(:, strcmpi(rawVarNames, 'ngdp'));
log_gdp         = raw_data(:, strcmpi(rawVarNames, 'log_gdp'));
cpi             = raw_data(:, strcmpi(rawVarNames, 'cpi'));
macro_unc100    = raw_data(:, strcmpi(rawVarNames, 'macro_unc100'));
log_neer        = raw_data(:, strcmpi(rawVarNames, 'log_neer'));
weighted_tau    = raw_data(:, strcmpi(rawVarNames, 'weighted_tau'));
fed_funds       = raw_data(:, strcmpi(rawVarNames, 'fed_funds'));
log_ea_gdp      = raw_data(:, strcmpi(rawVarNames, 'log_ea_gdp'));
ea_cpi          = raw_data(:, strcmpi(rawVarNames, 'ea_cpi'));
ea_euribor      = raw_data(:, strcmpi(rawVarNames, 'ea_euribor'));

% ── Construct ratio variables ─────────────────────────────────────────────
trade_balance_ngdp = 100 * (exp_nominal - imp_nominal) ./ ngdp;

if any(abs(ngdp) < 1e-12 | isnan(ngdp))
    warning('ngdp contains zero or missing values. Check trade_balance_ngdp.');
end

if any(~isfinite(trade_balance_ngdp))
    error('trade_balance_ngdp contains NaN or Inf. Check exp_nominal, imp_nominal and ngdp.');
end

varNames = {'log_gdp', ...
            'cpi', ...
            'log_neer', ...
            'trade_balance_ngdp', ...
            'macro_unc100', ...
            'fed_funds', ...
            'log_ea_gdp', ...
            'ea_cpi', ...
            'ea_euribor', ...
            'weighted_tau', ...
            'log_imp'};

% ── Final VAR data matrix ─────────────────────────────────────────────────
data = [log_gdp, ...
        cpi, ...
        log_neer, ...
        trade_balance_ngdp, ...
        macro_unc100, ...
        fed_funds, ...
        log_ea_gdp, ...
        ea_cpi, ...
        ea_euribor, ...
        weighted_tau, ...
        log_imp];

n_miss = sum(isnan(data(:)));

if n_miss > 0

    warning('%d missing value(s) detected:', n_miss);

    bad = find(any(isnan(data), 2));

    for i = 1:numel(bad)

        miss_vars = varNames(isnan(data(bad(i), :)));

        fprintf('  %s : missing %s\n', ...
                datestr(dates(bad(i)), 'yyyy-QQ'), ...
                strjoin(miss_vars, ', '));

    end

end

save(save_path, 'data', 'dates', 'varNames');

fprintf('Saved: %s\n', save_path);
fprintf('  Observations : %d  (%s  to  %s)\n', ...
        size(data, 1), ...
        datestr(dates(1), 'yyyy-mmm'), ...
        datestr(dates(end), 'yyyy-mmm'));
fprintf('  Variables    : %d\n', size(data, 2));

fprintf('\nVariables saved in VAR data matrix:\n');

for i = 1:numel(varNames)
    fprintf('  %2d: %s\n', i, varNames{i});
end
