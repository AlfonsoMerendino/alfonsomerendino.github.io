*===============================================================================
* STEP3_merge_STPU_figures.do 
*===============================================================================

clear all
set more off

global dir "`c(pwd)'"
cd "$dir"

do "codes/B1_STPU_merge.do" 
do "codes/A2_delta_tauF.do" 
do "codes/C_tau_s_filtered.do" 
