%% STEP2_estimate_STPU.m 

rootDir = fileparts(fileparts(mfilename('fullpath')));   % scripts/ -> package root
addpath(genpath(fullfile(rootDir, 'codes')));
A0_STPU_stochastic_volatility
