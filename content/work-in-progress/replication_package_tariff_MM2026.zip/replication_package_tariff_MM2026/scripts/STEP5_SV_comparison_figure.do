*===============================================================================
* STEP5_SV_comparison_figure.do 
*===============================================================================

clear all
set more off

global dir "`c(pwd)'"
cd "$dir"

do "codes/B2a_SV_WIT1_vs_STPU.do"
