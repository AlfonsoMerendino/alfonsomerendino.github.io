*===============================================================================
* STEP1_build_dataset.do 
*===============================================================================

clear all
set more off

global dir "`c(pwd)'"
cd "$dir"

do "codes/A1_dataset_construction.do"          // build base dataset -> dataset/data
