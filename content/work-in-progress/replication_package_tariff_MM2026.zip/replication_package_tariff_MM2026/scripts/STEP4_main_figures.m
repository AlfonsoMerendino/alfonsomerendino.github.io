%% STEP4_main_figures.m 

rootDir = fileparts(fileparts(mfilename('fullpath')));   % scripts/ -> package root
addpath(genpath(fullfile(rootDir, 'codes')));

B1b_SV_WIT1_STPU_dataset                       % SV_WIT1_STPU.csv (used by STEP 5)

% Build the three BVAR datasets
D1a_prepare_data_BVAR                          % TariffData_CA_neer.mat
D1c_prepare_data_BVAR_reer                     % TariffData_CA_reer.mat
D1d_prepare_data_BVAR_international            % TariffData_CA_international.mat
D1b_prepare_data_BVAR_treasury10y              % TariffData_CA_neer_treasury10y.mat

for anchorSet = ["baseline" "extended"]
    startYear = 1990; D2a_BVAR
    startYear = 2002; D2a_BVAR
    D2c_BVAR_reer
end

% NEER IRFs with the 10-year Treasury yield
startYear = 1990; anchorSet = 'baseline'; D2b_BVAR_treasury10y

% Euro-area IRFs
D2d_BVAR_international  

% Historical decomposition and FEVD
F_historical_decomposition  
H_plot_reer   
G_fevd_table 

% State-dependent local projections
E_LP_narrative_shocks 
