# Replication Package — *Tariffs, Uncertainty and the Exchange Rate*

Reproduces the figures and tables in the paper. 

## Folder structure

The five scripts to run sit in `scripts/`, numbered in run order:

```
Replication Package Tariffs/
├── README.md
├── run_all.sh                    one-command driver (runs steps 1-5 in order)
├── scripts/
│   ├── STEP1_build_dataset.do        Stata   (build dataset; Table 3 series)
│   ├── STEP2_estimate_STPU.m         MATLAB  (S-TPU series; calibration of Table 4)
│   ├── STEP3_merge_STPU_figures.do   Stata   (merge S-TPU + Fig 1, 2, 9)
│   ├── STEP4_main_figures.m          MATLAB  (Fig 3-7, 10, 13-19; Table 2)
│   └── STEP5_SV_comparison_figure.do Stata   (Fig 8)
├── codes/               analysis scripts (called by the STEP files)
│   └── functions/       MATLAB helpers (auto-added to path)
├── sources/             raw input data (exogenous)
├── dataset/             intermediate data built by the code (starts empty)
└── output/              figures, tables, saved results (starts empty)
```

## How paths are set

- **MATLAB**: each script in `codes/` uses `codeDir = fileparts(mfilename('fullpath'))`
  and `rootDir = fileparts(codeDir)`; it reads from `rootDir/dataset` and
  `rootDir/sources` and writes to `rootDir/output`. The STEP launchers in
  `scripts/` resolve the package root the same way (one level up). Nothing to edit.
- **Stata**: each STEP file sets `global dir` to `c(pwd)`, so `cd` to the
  package root before running (`do scripts/STEP1_build_dataset.do`). The
  do-files in `codes/` fall back to the same rule, stripping a trailing
  `codes` component, so running one directly from `codes/` also resolves
  the package root. Setting `global dir` beforehand overrides both.


## How to run

Unzip the package anywhere not synced by OneDrive, Dropbox or Google Drive.
Open a terminal — Git Bash on Windows, Terminal on macOS — 
then replace "/path/to/Replication Package Tariffs"
below with the folder you unzipped, and run in the terminal:

```bash
cd "/path/to/Replication Package Tariffs" && chmod +x run_all.sh && ./run_all.sh
```

**macOS / Linux**: nothing else to do. `run_all.sh` finds Stata in
`/Applications` and MATLAB in `/Applications/MATLAB_R20*.app`.

**Windows**: run the same command from **Git Bash** (not `cmd.exe` or
PowerShell). `run_all.sh` finds `C:\Program Files\Stata*\Stata*-64.exe` and
`C:\Program Files\MATLAB\R20*\bin\matlab.exe`. Two Windows-only notes:

- **Do not run the package inside a synced folder** (Dropbox, OneDrive,
  Google Drive). Copy the package to a local folder, run it there, and copy
  `dataset/` and `output/` back — or pause syncing for the duration.
- **If STEP1 aborts with `Java installation not found`, `r(5004)`**, Stata
  cannot see its own bundled JDK, which `import delimited` needs to detect
  file encodings. Fix it once, from any Stata session:

  ```
  set java_home "C:/Program Files/StataNow19/utilities/java/windows-x64/zulu-jdk21.0.6"
  ```

  Adjust the path to match your Stata version. The setting persists.

If either program is installed somewhere unusual, point at it directly:

```bash
STATA="/c/Program Files/StataNow19/StataSE-64.exe" ./run_all.sh
```

The steps must run in order, since each consumes what the previous ones wrote.

Please note that the code F_historical_decomposition in Step 4 can take around 14 hours.


## Requirements

- MATLAB R2020a or later, with the Statistics and Machine Learning Toolbox
  (`quantile`, `prctile`). `F_historical_decomposition.m` uses `parfor`, which
  runs serially without the Parallel Computing Toolbox.
- Stata (uses the `Garamond` font for figures; falls back gracefully if absent).
- A bash shell: standard on macOS/Linux; on Windows use **Git Bash**, which
  ships with Git for Windows (<https://gitforwindows.org>).

`dataset/` and `output/` must exist and start empty. `run_all.sh` recreates
them if a distribution channel dropped them for being empty.
