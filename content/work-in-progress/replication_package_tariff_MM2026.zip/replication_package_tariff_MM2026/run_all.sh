#!/usr/bin/env bash
#===============================================================================
# run_all.sh - run the full replication pipeline in order, end to end.
#
# Requires Stata and MATLAB on the PATH. Runs on macOS/Linux and on Windows
# under Git Bash (see README).
# Override the executables if they are named differently, e.g.:
#     STATA=stata-se MATLAB=/Applications/MATLAB_R2024b.app/bin/matlab ./run_all.sh
#===============================================================================
set -euo pipefail
cd "$(dirname "$0")"                 # package root
ROOT=$(pwd -P)
for d in codes scripts sources; do
    [ -d "$d" ] || { echo "ERROR: package root does not look right - '$d/' not found beside run_all.sh" >&2; exit 1; }
done

# Locate Stata and MATLAB: honour $STATA / $MATLAB, else look on the PATH, else
# fall back to the usual macOS install locations (Stata ships as an .app whose
# console binary is not on the PATH by default) and then to the usual Windows
# install locations (neither Stata nor MATLAB is on the PATH there by default).
find_exe () {                        # find_exe <candidates...>
    for c in "$@"; do
        if [ -x "$c" ]; then echo "$c"; return 0; fi
        if command -v "$c" >/dev/null 2>&1; then command -v "$c"; return 0; fi
    done
    return 1
}

STATA=${STATA:-$(find_exe stata-mp stata-se stata \
    /Applications/StataNow/StataMP.app/Contents/MacOS/stata-mp \
    /Applications/StataNow/StataSE.app/Contents/MacOS/stata-se \
    /Applications/Stata/StataMP.app/Contents/MacOS/stata-mp \
    /Applications/Stata/StataSE.app/Contents/MacOS/stata-se \
    "$(ls -d "/c/Program Files"/Stata*/Stata*-64.exe 2>/dev/null | tail -1)" \
    || true)}
MATLAB=${MATLAB:-$(find_exe matlab /Applications/MATLAB_R2026a.app/bin/matlab \
    "$(ls -d /Applications/MATLAB_R20*.app/bin/matlab 2>/dev/null | tail -1)" \
    "$(ls -d "/c/Program Files"/MATLAB/R20*/bin/matlab.exe 2>/dev/null | tail -1)" \
    || true)}

[ -n "$STATA" ]  || { echo "ERROR: Stata not found. Set STATA=/path/to/stata-se"  >&2; exit 1; }
[ -n "$MATLAB" ] || { echo "ERROR: MATLAB not found. Set MATLAB=/path/to/matlab" >&2; exit 1; }
echo "Package root: $ROOT"
echo "Stata       : $STATA"
echo "MATLAB      : $MATLAB"
echo

mkdir -p dataset output              # both start empty; some distribution
                                     # channels drop empty directories

# Stata's batch mode exits 0 even when a do-file aborts, so `set -e` cannot see
# the failure on its own. Check the log for an error return code instead.
#
# On Windows, `import delimited` starts a JVM for encoding detection, and Stata
# then finishes the do-file (writing every output) but never exits - it wedges
# in JVM teardown. So rather than waiting on the process, wait for it to exit OR
# for the log to stop growing for STATA_IDLE seconds, then terminate it. On
# macOS/Linux Stata exits normally and the loop simply breaks on exit.
run_stata () {
    local dofile=$1
    local logfile="${dofile##*/}"; logfile="${logfile%.do}.log"
    rm -f "$logfile"
    "$STATA" -b do "$dofile" &
    local pid=$! size="" last="" quiet=0
    while kill -0 "$pid" 2>/dev/null; do
        sleep 10
        size=$( [ -f "$logfile" ] && wc -c < "$logfile" || echo 0 )
        if [ "$size" = "$last" ]; then
            quiet=$((quiet + 10))
            if [ "$quiet" -ge "${STATA_IDLE:-240}" ]; then
                echo "   (do-file finished; terminating wedged Stata process)"
                kill "$pid" 2>/dev/null || true
                break
            fi
        else
            quiet=0; last=$size
        fi
    done
    wait "$pid" 2>/dev/null || true
    [ -f "$logfile" ] || { echo "ERROR: Stata produced no log for $dofile" >&2; exit 1; }
    if grep -qE '^r\([0-9]+\);' "$logfile"; then
        echo "ERROR: Stata failed in $dofile - see $logfile:" >&2
        grep -nE -B5 '^r\([0-9]+\);' "$logfile" | tail -20 >&2
        exit 1
    fi
}

echo "[1/5] Stata  : STEP 1: build base dataset"
run_stata scripts/STEP1_build_dataset.do

echo "[2/5] MATLAB : STEP 2: S-TPU estimation"
"$MATLAB" -batch "run('scripts/STEP2_estimate_STPU.m')"

echo "[3/5] Stata  : STEP 3"
run_stata scripts/STEP3_merge_STPU_figures.do

echo "[4/5] MATLAB : STEP 4"
"$MATLAB" -batch "run('scripts/STEP4_main_figures.m')"

echo "[5/5] Stata  : STEP 5: Tariff SV vs S-TPU figure"
run_stata scripts/STEP5_SV_comparison_figure.do

echo
echo "Done. Figures and tables are in output/."
